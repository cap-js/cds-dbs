const { expBkfRnd: waitingTime } = require('../../common/utils/waitingTime')

const _rmHandlers = client => {
  client.removeAllListeners('connected')
  client.removeAllListeners('error')
  client.removeAllListeners('disconnected')
}

const connect = (client, LOG, keepAlive) => {
  return new Promise((resolve, reject) => {
    _rmHandlers(client)

    client
      .once('connected', function () {
        _rmHandlers(client)

        // It's important to _always_ keep an error listener,
        // otherwise it will throw and crash the server
        client.on('error', err => LOG(err?.message))

        if (keepAlive) {
          client.on('disconnected', () => {
            let connected = false
            client.once('connected', () => {
              LOG('Reconnected')
              connected = true
            })
            let x = 1
            const _untilConnected = async () => {
              if (!connected) {
                LOG('Reconnecting')
                try {
                  client.connect()
                } catch {
                  // we try again...
                }
                setTimeout(_untilConnected, waitingTime(x++)).unref()
              }
            }
            _untilConnected()
          })
        }

        resolve(client)
      })
      .once('error', err => {
        _rmHandlers(client)
        const e = new Error('Connection error')
        e.cause = err
        reject(e)
      })

    try {
      client.connect()
    } catch (e) {
      reject(e)
    }
  })
}

const disconnect = client => {
  return new Promise((resolve, reject) => {
    _rmHandlers(client)

    client.once('disconnected', () => {
      client.removeAllListeners('error')
      resolve()
    })
    client.once('error', err => {
      client.removeAllListeners('disconnected')
      reject(err)
    })

    client.disconnect()
  })
}

module.exports = {
  connect,
  disconnect
}
