const cds = require('../../cds')
const { findLocalDestinations } = require('./fetchClient')

let _cloudSdkConnectivity
const getCloudSdkConnectivity = () => (_cloudSdkConnectivity ??= require('@sap-cloud-sdk/connectivity'))

let _cloudSdkResilience
const getCloudSdkResilience = () => (_cloudSdkResilience ??= require('@sap-cloud-sdk/resilience'))

let _cloudSdk
const getCloudSdk = () => {
  _cloudSdk ??= require('@sap-cloud-sdk/http-client')
  const { version } = require('@sap-cloud-sdk/http-client/package.json')
  if (version && Number(version.split('.')[0]) < 4)
    cds.utils.deprecated({ old: `SAP Cloud SDK version ${version} `, use: `SAP Cloud SDK version >= 4.` })
  return _cloudSdk
}

let _cloudSdkInstalled
const isCloudSdkInstalled = () => {
  if (_cloudSdkInstalled === undefined) {
    try {
      getCloudSdk()
      _cloudSdkInstalled = true
    } catch {
      _cloudSdkInstalled = false
    }
  }
  return _cloudSdkInstalled
}

const shouldUseCloudSdk = destination => {
  // Native node fetch for named destinations is supported only if locally resolvable via process.env.destinations
  const _destination = typeof destination === 'string' ? findLocalDestinations(destination)[0] : destination
  if (!_destination?.url) return true
  if (_destination.authentication && !(_destination.authentication in { NoAuthentication: 1, BasicAuthentication: 1 }))
    return true
  // here, it would be _possible_ to use native fetch
  // explicit config?
  if (cds.env.remote?.native_fetch != null) return !cds.env.remote.native_fetch
  // if cloud sdk is there, use it
  return isCloudSdkInstalled()
}

module.exports = {
  getCloudSdkConnectivity,
  getCloudSdkResilience,
  getCloudSdk,
  shouldUseCloudSdk
}
