const cds = require('../../cds')
const LOG = cds.log('remote')

const { Readable } = require('stream')

// process.env.destinations — CloudSDK convention for local destination resolution:
// a JSON array of { name, url, ... } objects, e.g. for local development or testing.
const findLocalDestinations = name => {
  const raw = process.env.destinations
  if (!raw) return []
  try {
    return JSON.parse(raw).filter(d => (d.name ?? d.Name) === name)
  } catch (e) {
    LOG.warn(`Failed to parse 'destinations' env variable:`, e.message)
    return []
  }
}

const _resolveDestination = destination => {
  if (destination.url) return destination

  const matches = findLocalDestinations(destination.destinationName)
  if (matches.length > 1)
    LOG.warn(
      `'destinations' env variable contains multiple entries with name '${destination.destinationName}'. Only the first will be used.`
    )
  const found = matches[0]
  if (found?.url) {
    // Normalize PascalCase 'Name' to lowercase (BTP Destination Service API uses PascalCase)
    if (found.Name && !found.name) found.name = found.Name
    return { ...destination, ...found }
  }

  // REVISIT: resolve named destination via BTP Destination Service

  throw new Error(`Cannot resolve destination '${destination.destinationName}'.`)
}

// REVISIT: parity gaps vs CloudSDK's csrf-token-middleware.js:
//   1. Slash retry — CloudSDK tries preflight with trailing slash first, then without,
//      to work around an S/4HANA redirect quirk (axios#3369).
//   2. Cookie forwarding — CloudSDK extracts set-cookie from the preflight response
//      and forwards it as a cookie header on the actual request.
//   3. content-length: 0 — CloudSDK sets this on the preflight request headers.
//   4. Token in error response — CloudSDK also checks error response headers for the
//      token (some servers return it even on 4xx); we swallow preflight errors entirely.
const _fetchCsrfToken = async (url, headers, csrf, signal) => {
  try {
    const method = (csrf.method || 'head').toUpperCase()
    const res = await fetch(url, { method, headers: { ...headers, 'x-csrf-token': 'Fetch' }, signal })
    return res.headers.get('x-csrf-token')
  } catch (e) {
    // proceed without token; actual request may fail with 403
    LOG._debug && LOG.debug('CSRF token fetch failed:', e)
  }
}

const _readBody = async (response, responseType) => {
  switch (responseType) {
    case 'stream':
      return Readable.fromWeb(response.body)
    case 'json':
      return response.json()
    case 'text':
      return response.text()
    case 'arraybuffer':
      return response.arrayBuffer().then(Buffer.from)
  }
  // Content-type fallback when no responseType was set
  const ct = response.headers.get('content-type')
  if (/stream|image|pdf|tar/.test(ct)) return Readable.fromWeb(response.body)
  if (/xml|html/.test(ct)) return response.text()
  const text = await response.text()
  try {
    return JSON.parse(text)
  } catch {
    return text
  }
}

/**
 * Native-fetch HTTP executor.
 */
const executeHttpRequest = async (destination, requestConfig) => {
  // Resolve destination
  destination = _resolveDestination(destination)
  const baseUrl = (destination.url || '').replace(/\/$/, '')

  const { method = 'GET', url = '', data, responseType, maxBodyLength, timeout, csrf } = requestConfig
  const signal = timeout ? AbortSignal.timeout(timeout) : undefined // eslint-disable-line no-undef

  // Assemble headers
  const headers = { ...destination.headers, ...requestConfig.headers }
  if (!headers.authorization) {
    const { authentication } = destination
    if (!authentication || authentication === 'BasicAuthentication') {
      const { username, password } = destination
      if (username && password) {
        headers.authorization = 'Basic ' + Buffer.from(`${username}:${password}`).toString('base64')
      } else {
        LOG.warn(
          `Credentials for destination '${destination.name || destination.destinationName}' configured with basic authentication but missing "username" or "password".`
        )
      }
    }
  }

  if (csrf && method !== 'GET' && method !== 'HEAD') {
    const token = await _fetchCsrfToken(baseUrl + url, headers, csrf, signal)
    if (token) headers['x-csrf-token'] = token
  }

  // Serialize body
  let body
  if (data !== undefined && method !== 'GET' && method !== 'HEAD') {
    if (typeof data === 'string' || Buffer.isBuffer(data) || typeof data.pipe === 'function') body = data
    else body = JSON.stringify(data)
  }

  if (maxBodyLength && body) {
    const len = Buffer.isBuffer(body) ? body.length : Buffer.byteLength(body)
    if (len > maxBodyLength)
      throw new Error(`Request body length ${len} exceeds configured max_body_length ${maxBodyLength}.`)
  }

  // Build URL
  let fullUrl = baseUrl + (url && !url.startsWith('/') ? `/${url}` : url)
  const { queryParameters } = destination
  if (queryParameters && Object.keys(queryParameters).length) {
    const qs = new URLSearchParams(Object.entries(queryParameters).map(([k, v]) => [k, String(v)])).toString()
    fullUrl += (fullUrl.includes('?') ? '&' : '?') + qs
  }

  if (LOG._debug) LOG.debug(`${method} ${fullUrl}`)

  // Execute request
  let response
  try {
    response = await fetch(fullUrl, { method, headers, body, signal })
  } catch (e) {
    const timedOut = e.name === 'TimeoutError'
    const msg = timedOut ? `Exceeded timeout of ${timeout}ms.` : e.message
    throw Object.assign(new Error(msg), { cause: e })
  }

  // Parse response
  const { status, statusText } = response
  const responseHeaders = Object.fromEntries(response.headers)
  const responseData = await _readBody(response, response.ok ? responseType : undefined)

  if (!response.ok) {
    const err = new Error(`Request to remote service failed with status ${status}.`)
    err.response = { status, statusText, headers: responseHeaders, data: responseData }
    throw err
  }

  return { data: responseData, headers: responseHeaders, status }
}

module.exports = { executeHttpRequest, findLocalDestinations }
