const cds = require('../cds')
const LOG = cds.log('fiori|drafts')

const { Object_keys } = cds.utils

const { Readable, PassThrough } = require('stream')

const { getPageSize, commonGenericPaging } = require('../common/generic/paging')
const { getPreferReturnHeader } = require('../../odata/utils')
const { commonGenericSorting } = require('../common/generic/sorting')
const { addEtagColumns } = require('../common/utils/etag')
const { handleStreamProperties } = require('../common/utils/streamProp')

const { prototype: odata } = require('../../odata/ODataAdapter')
const { Responses, prepareError } = require('../../../lib/req/response')
const location4 = require('../../http/location')

const $original = Symbol('original')
const $draftParams = Symbol('draftParams')

const { WELL_KNOWN_EVENTS } = require('../../../lib/req/event')

const AGGREGATION_FUNCTIONS = ['sum', 'min', 'max', 'avg', 'average', 'count']
const MAX_RECURSION_DEPTH = cds.env.features.recursion_depth != null ? Number(cds.env.features.recursion_depth) : 4
const IS_PERSISTED_DRAFT_MESSAGES_ENABLED =
  !!cds.model?.definitions?.['DRAFT.DraftAdministrativeData']?.elements?.DraftMessages

const _config_to_ms = (config, _default) => {
  const timeout = cds.env.fiori?.[config]
  let timeout_ms
  if (timeout === true) {
    timeout_ms = cds.utils.ms4(_default)
  } else if (typeof timeout === 'string') {
    timeout_ms = cds.utils.ms4(timeout)
    if (!timeout_ms)
      cds.error`
${timeout} is an invalid value for \`cds.fiori.${config}\`.
Please provide a value in format /^([0-9]+)(w|d|h|hrs|min)$/.
`
  } else {
    timeout_ms = timeout
  }

  return timeout_ms
}

const DEL_TIMEOUT = {
  get value() {
    const timeout_ms = _config_to_ms('draft_deletion_timeout', '30d')
    Object.defineProperty(DEL_TIMEOUT, 'value', { value: timeout_ms })
    return timeout_ms
  }
}

const LOCK_TIMEOUT = {
  get value() {
    let timeout_ms = _config_to_ms('draft_lock_timeout', '15min')

    Object.defineProperty(LOCK_TIMEOUT, 'value', { value: timeout_ms })
    return timeout_ms
  }
}

const reject_bypassed_draft = () => {
  const message =
    !cds.profiles?.includes('production') &&
    '`cds.fiori.bypass_draft` must be enabled to support direct modifications of active instances.'
  cds.error({ status: 501, message })
}

const DRAFT_ELEMENTS = new Set([
  'IsActiveEntity',
  'HasDraftEntity',
  'HasActiveEntity',
  'DraftAdministrativeData',
  'DraftAdministrativeData_DraftUUID',
  'SiblingEntity'
])
const DRAFT_ELEMENTS_WITHOUT_HASACTIVE = new Set(DRAFT_ELEMENTS)
DRAFT_ELEMENTS_WITHOUT_HASACTIVE.delete('HasActiveEntity')
const REDUCED_DRAFT_ELEMENTS = new Set(['IsActiveEntity', 'HasDraftEntity', 'SiblingEntity'])

const numericCollator = { numeric: true }
const emptyObject = {}

const _isKeyValue = (i, keys, where) => {
  if (!where[i].ref || !keys.includes(where[i].ref[0])) {
    return false
  }

  return where[i + 1] === '=' && 'val' in where[i + 2]
}

const _getKeyData = (keys, where) => {
  if (!where) {
    return {}
  }

  const data = {}
  let i = 0

  while (where[i]) {
    if (_isKeyValue(i, keys, where)) {
      data[where[i].ref[0]] = where[i + 2].val
      i = i + 3
    } else {
      i++
    }
  }

  return data
}

const _fillIsActiveEntity = (row, IsActiveEntity, target) => {
  if (target.drafts) row.IsActiveEntity = IsActiveEntity
  for (const key in target.associations) {
    const prop = row[key]
    if (!prop) continue
    const el = target.elements[key]
    const childIsActiveEntity = el._target.isDraft ? IsActiveEntity : true
    const propArray = Array.isArray(prop) ? prop : [prop]
    propArray.forEach(r => _fillIsActiveEntity(r, childIsActiveEntity, el._target))
  }
}

const _filterResultSet = (resultSet, limit, offset) => {
  const pageResultSet = []

  for (let i = 0; i < resultSet.length; i++) {
    if (i < offset) continue
    pageResultSet.push(resultSet[i])
    if (pageResultSet.length === limit) break
  }

  return pageResultSet
}

// It's important to wait for the completion of all promises, otherwise a rollback might happen too soon
const _promiseAll = async array => {
  const results = await Promise.allSettled(array)
  const firstRejected = results.find(response => response.status === 'rejected')
  if (firstRejected) throw firstRejected.reason
  return results.map(result => result.value)
}

const _isCount = query => query.SELECT.columns?.length === 1 && query.SELECT.columns[0].func === 'count'
const _entityKeys = entity =>
  Object_keys(entity.keys).filter(key => key !== 'IsActiveEntity' && !entity.keys[key].isAssociation)

const _inProcessByUserXpr = lockShiftedNow => ({
  xpr: [
    'case',
    'when',
    { ref: ['LastChangeDateTime'] },
    '<',
    { val: lockShiftedNow },
    'then',
    { val: '' },
    'else',
    { ref: ['InProcessByUser'] },
    'end'
  ],
  as: 'InProcessByUser',
  cast: { type: 'cds.String' }
})

const _lock = {
  get shiftedNow() {
    return new Date(Math.max(0, Date.now() - LOCK_TIMEOUT.value)).toISOString()
  }
}

const _redirectRefToDrafts = (ref, model) => {
  const [root, ...tail] = ref
  const target = model.definitions[root.id || root]
  const draft = target.drafts || target
  return [root.id ? { ...root, id: draft.name } : draft.name, ...tail]
}

const _redirectRefToActives = (ref, model) => {
  const [root, ...tail] = ref
  const target = model.definitions[root.id || root]
  const active = target.actives || target
  return [root.id ? { ...root, id: active.name } : active.name, ...tail]
}

const lastCheckMap = new Map()
const _cleanUpOldDrafts = (service, tenant) => {
  if (!DEL_TIMEOUT.value) return

  const expiryDate = new Date(Date.now() - DEL_TIMEOUT.value).toISOString()
  const interval = DEL_TIMEOUT.value / 2
  const lastCheck = lastCheckMap.get(tenant)

  if (lastCheck && Date.now() - lastCheck < Number(interval)) return

  cds.spawn({ tenant, user: cds.User.privileged }, async () => {
    const expiredDrafts = await SELECT.from('DRAFT.DraftAdministrativeData', ['DraftUUID']).where(
      `LastChangeDateTime <`,
      expiryDate
    )

    if (!expiredDrafts.length) return

    const expiredDraftsIds = expiredDrafts.map(el => el.DraftUUID)
    const promises = []

    const draftRoots = []

    for (const name in service.model.definitions) {
      const target = service.model.definitions[name]
      if (target.drafts && target['@Common.DraftRoot.ActivationAction']) {
        draftRoots.push(target.drafts)
      }
    }

    const draftRootIds = await Promise.all(
      draftRoots.map(draftRoot =>
        SELECT.from(draftRoot, _entityKeys(draftRoot)).where(`DraftAdministrativeData_DraftUUID IN`, expiredDraftsIds)
      )
    )

    for (let i = 0; i < draftRoots.length; i++) {
      const ids = draftRootIds[i]
      if (!ids.length) continue
      const srv = await cds.connect.to(draftRoots[i]._service.name).catch(() => {})
      if (!srv) continue // srv might not be loaded
      for (const idObj of ids) {
        promises.push(srv.send({ event: 'CANCEL', query: DELETE.from(draftRoots[i], idObj), data: idObj }))
      }
    }

    await Promise.allSettled(promises)
  })

  lastCheckMap.set(tenant, Date.now())
}

const _hasStreaming = (cols, target, deep) => {
  return cols?.some(col => {
    const name = col.as || col.ref?.at(-1)
    if (!target.elements[name]) return
    return (
      target.elements[name]._type === 'cds.LargeBinary' ||
      (deep && col.expand && _hasStreaming(col.expand, target.elements[name]._target, deep))
    )
  })
}

const _waitForReadable = readable => {
  return new Promise((resolve, reject) => {
    readable.once('readable', resolve)
    readable.once('error', reject)
  })
}

const _removeEmptyStreams = async result => {
  if (!result) return

  const res = Array.isArray(result) ? result : [result]
  for (let r of res) {
    for (let key in r) {
      const el = r[key]
      if (el instanceof Readable) {
        // In case hana-client Readable may not be ready
        if (cds.db?.constructor?.name === 'HANAService') await _waitForReadable(el)
        const chunk0 = el.read()
        if (chunk0 === null) delete r[key]
        else el.unshift(chunk0)
      } else if (typeof el === 'object') {
        const res = Array.isArray(el) ? el : [el]
        for (let r of res) {
          await _removeEmptyStreams(r)
        }
      }
    }
  }
}

const getUpdateFromSelectQueries = (target, draftRef, activeRef, depth = 0) => {
  const updateMediaDataQueries = []

  // Collect relevant elements
  const compositionElements = []
  const mediaDataElements = []
  const autogeneratedElements = []
  const targetElements = Array.isArray(target.elements) ? target.elements : Object.values(target.elements)
  for (const element of targetElements) {
    if (element['@cds.on.update']) autogeneratedElements.push(element)
    else if (element.isComposition) compositionElements.push(element)
    else if (element._type === 'cds.LargeBinary') mediaDataElements.push(element)
  }

  // Recurse into compositions
  const nextDepth = depth + 1
  if (nextDepth <= MAX_RECURSION_DEPTH) {
    for (const composition of compositionElements) {
      const compositionTargetElement = cds.model.definitions[composition.target]

      const nextDraftRef = [...draftRef, composition.name]
      const nextActiveRef = [...activeRef, composition.name]

      updateMediaDataQueries.push(
        ...getUpdateFromSelectQueries(compositionTargetElement, nextDraftRef, nextActiveRef, nextDepth)
      )
    }
  }

  // Construct update queries for media data elements
  if (mediaDataElements.length) {
    const updateWith = {}
    for (const element of autogeneratedElements) {
      updateWith[element.name] = { ref: ['active', element.name] }
    }

    // Construct WHERE to match draft and active entities
    const selectWhere = Object.values(target.keys).reduce((acc, key) => {
      if (key.virtual || key.isAssociation) return acc
      if (acc.length) acc.push('and')
      acc.push({ ref: ['draft', key.name] })
      acc.push('=')
      acc.push({ ref: ['active', key.name] })
      return acc
    }, [])

    for (const element of mediaDataElements) {
      const activeElementRef = { ref: ['active', element.name] }
      const draftElementRef = { ref: ['draft', element.name] }

      // cds.ql.xpr`CASE WHEN (${draftElementRef} IS NULL OR length(${draftElementRef}) > 0) THEN ${draftElementRef} ELSE ${activeElementRef} END`
      const columnExpression = {
        xpr: [
          'case',
          'when',
          {
            xpr: [
              draftElementRef,
              '=',
              { val: null },
              'or',
              { func: 'length', args: [draftElementRef] },
              '>',
              { val: 0 }
            ]
          },
          'then',
          draftElementRef,
          'else',
          activeElementRef,
          'end'
        ]
      }
      columnExpression.as = element.name

      const qSelectNextMediaData = SELECT.columns([columnExpression])
        .from({ ref: draftRef, as: 'draft' })
        .where(selectWhere)

      updateWith[element.name] = qSelectNextMediaData
    }

    // Construct & Collect the actual update query for this composition level
    const updateMediaDataQuery = UPDATE.entity({ ref: activeRef, as: 'active' }).with(updateWith)
    updateMediaDataQueries.push(updateMediaDataQuery)
  }

  return updateMediaDataQueries
}

// REVISIT: Can be replaced with SQL WHEN statement (see commented code in expandStarStar) in the new HANA db layer - doesn't work with old db layer
const _replaceStreams = result => {
  if (!result) return

  const res = Array.isArray(result) ? result : [result]
  for (let r of res) {
    for (let key in r) {
      const el = r[key]
      if (el instanceof Readable) {
        const stream = new Readable()
        stream.push(null)
        r[key] = stream
      } else if (typeof el === 'object') {
        const res = Array.isArray(el) ? el : [el]
        res.forEach(_replaceStreams)
      }
    }
  }
}

const _extractPrefixRef = (draftsRef, targetEntity, requestData = null) => {
  const prefixRef = []
  for (let refIdx = 0; refIdx < draftsRef.length; refIdx++) {
    const dRef = draftsRef[refIdx],
      dRefId = dRef.id ?? dRef

    // Determine entity, referenced by the processesd segment of 'draftsRef'
    if (refIdx > 0) targetEntity = targetEntity.elements[dRefId]._target

    // Construct 'prefixRef' segment
    const pRef = { where: [] }

    if (dRefId === targetEntity.name) {
      pRef.id = targetEntity.isDraft ? targetEntity.actives.name : targetEntity.name
    } else pRef.id = dRefId

    if (targetEntity.isDraft) targetEntity = targetEntity.actives

    if ((typeof dRef === 'string' || !dRef.where?.length) && requestData) {
      // In case of CREATE: The WHERE for the created entity must be constructed for use in 'prefixRef'

      for (const k in targetEntity.keys) {
        const key = targetEntity.keys[k]
        let v = requestData[key.name]
        if (v === undefined)
          if (key.name === 'IsActiveEntity') v = false
          else return null
        if (v instanceof Buffer) v = v.toString('base64') //> convert binary keys to base64
        if (pRef.where.length > 0) pRef.where.push('and')
        pRef.where.push({ ref: [key.name] }, '=', { val: v })
      }

      prefixRef.push(pRef)
      continue
    }

    if (dRef.where?.length) {
      // Use the existing where clause from draftRef
      pRef.where.push(...dRef.where)

      if (!pRef.where.some(w => w === 'IsActiveEntity' || w.ref?.[0] === 'IsActiveEntity'))
        pRef.where.push('and', { ref: ['IsActiveEntity'] }, '=', { val: false })

      prefixRef.push(pRef)
      continue
    }

    prefixRef.push(pRef.id)
  }

  return prefixRef
}

const compileUpdatedDraftMessages = (newMessages, persistedMessages, requestData, draftsRef) => {
  const txModel = cds.context.tx.model // REVISIT: prefer srv.model!
  let targetEntity = txModel.definitions[draftsRef[0].id || draftsRef[0]]

  // The 'target' of validation errors needs to specify the full path from the draft root
  // > Since success of establishment of containment can't be guaranteed, we clean up messages
  if (!targetEntity['@Common.DraftRoot.ActivationAction']) return []

  // Determine the path prefix required for a fully qualified validation message 'target'
  const prefixRef = _extractPrefixRef(draftsRef, targetEntity, requestData)
  if (!prefixRef) return null

  const draftMessageTargetPrefix = cds.odata.urlify(
    { SELECT: { from: { ref: prefixRef } } },
    { kind: 'odata-v4', model: txModel }
  ).path

  const nextMessages = []

  // Collect messages that were created during the most recent validation run
  const newMessagesByMessageKeyAndTarget = newMessages.reduce((acc, message) => {
    if (!message.target) return acc //> silently ignore messages without target

    message.numericSeverity ??= 4
    message.additionalTargets = message.additionalTargets?.map(t => t.replace(/^in\//, ''))

    // Remove prefix 'in/' in favor of fully qualified path to the target
    const messageTarget = message.target.replace(/^in\//, '')

    // Process the message target produced by validation
    // > The message target contains the relative path of the erroneous entity
    // > For a message specific 'prefixRef', this info must be added to the entity 'prefixRef'
    const messagePrefixRef = [...prefixRef]
    const messageTargetRef = cds.odata.parse(messageTarget).SELECT.from.ref
    message.target = messageTargetRef.pop()

    for (const tRef of messageTargetRef) {
      messagePrefixRef.push(tRef)
      if ((tRef.where ??= []).some(w => w === 'IsActiveEntity' || w.ref?.[0] === 'IsActiveEntity')) continue
      if (tRef.where.length > 0) tRef.where.push('and', 'IsActiveEntity', '=', false)
    }

    message.prefix = cds.odata.urlify(
      { SELECT: { from: { ref: messagePrefixRef } } },
      { kind: 'odata-v4', model: txModel }
    ).path

    nextMessages.push(message)

    return acc.set(`${message.message}:${message.prefix}:${message.target}`, message)
  }, new Map())

  // Merge new messages with persisted ones & eliminate outdated ones
  const simplePathElements = prefixRef.map(pRef => pRef.id)
  for (const message of persistedMessages) {
    // Drop persisted draft messages that are replaced by new ones
    if (newMessagesByMessageKeyAndTarget.has(`${message.message}:${message.prefix}:${message.target}`)) continue
    const hasNewMessageForAdditionalTarget = message.additionalTargets?.some(target =>
      newMessagesByMessageKeyAndTarget.has(`${message.message}:${message.prefix}:${target}`)
    )
    if (hasNewMessageForAdditionalTarget) continue

    // Drop persisted draft messages where the value of the target field changed
    if (message.prefix === draftMessageTargetPrefix) {
      if (requestData[message.target] !== undefined) continue
      if (message.additionalTargets?.some(target => requestData[target] !== undefined)) continue
    }

    // Drop persisted draft messages, whose target's use navigations, where the value of the target field changed
    const messageSimplePathElements = message.prefix.replaceAll(/\([^(]*\)/g, '').split('/')
    if (messageSimplePathElements.length > simplePathElements.length)
      if (requestData[messageSimplePathElements[simplePathElements.length]] !== undefined) continue

    nextMessages.push(message)
  }

  return nextMessages.map(msg => odata.normalized(msg))
}

const _createNewDraftData = (obj, target, draftUUID) => {
  const newDraftData = Object.assign({}, obj, {
    DraftAdministrativeData_DraftUUID: draftUUID,
    HasActiveEntity: false
  })
  if (!target) return newDraftData

  for (const key in newDraftData) {
    if (!target.elements[key]?.isComposition) continue

    // Recurse into payload entries for nested associated entities
    if (Array.isArray(newDraftData[key]))
      newDraftData[key] = newDraftData[key].map(v => _createNewDraftData(v, target.elements[key]._target, draftUUID))
    else if (typeof newDraftData[key] === 'object')
      newDraftData[key] = _createNewDraftData(newDraftData[key], target.elements[key]._target, draftUUID)
  }

  return newDraftData
}

const _newReq = (req, query, draftParams, { event, headers }) => {
  // REVISIT: This is a bit hacky -> better way?
  query._target = undefined
  query[$draftParams] = draftParams

  // REVISIT: This is extremely bad. We should be able to just create a copy without such hacks.
  const _req = cds.Request.for(req._) // REVISIT: this causes req._.data of WRITE reqs copied to READ reqs
  // To create a `READ` event based on a modifying request, we need to delete req.data
  if (event === 'READ' && req.event !== 'READ') delete _req.data

  if (headers) {
    _req.headers = Object.create(req.headers)
    Object.assign(_req.headers, headers)
  }

  // Set relevant attributes of the inner request based on the outer
  _req.target = cds.infer.target(query)
  _req.query = query
  _req.params = req.params
  _req._ = req._

  const cqnData = _req.query.UPDATE?.data || _req.query.INSERT?.entries?.[0]
  if (cqnData) _req.data = cqnData // must point to the same object

  if (req.protocol) _req.protocol = req.protocol
  if (!_req._.event) _req._.event = req.event
  if (req.tx && !_req.tx) _req.tx = req.tx

  // Determine the proper event for the inner request
  if (event) _req.event = event
  else if (query.SELECT) _req.event = 'READ'
  else if (query.INSERT) _req.event = 'CREATE'
  else if (query.UPDATE) _req.event = 'UPDATE'
  else if (query.DELETE) _req.event = 'DELETE'
  else _req.event = req.event

  // Divert messages and validation errors to outer request
  /* prettier-ignore */ Object.defineProperty(_req, '_messages', { get() { return req._messages } })
  /* prettier-ignore */ Object.defineProperty(_req, '_validationErrors', { get() { return req._validationErrors } })

  const shouldCollectValidationErrorsSeparately =
    _req.target.isDraft && IS_PERSISTED_DRAFT_MESSAGES_ENABLED && req.protocol && ['UPDATE', 'NEW'].includes(_req.event)
  if (shouldCollectValidationErrorsSeparately) {
    // Add a separate collection for validation errors, to the outer request
    req._validationErrors ??= new Responses()

    // Override .error to collect validation errors separately, for the inner request
    // > Validation errors being classified by having a 'target'
    _req.error = (...args) => {
      const err = prepareError(4, ...args)
      if (err.target) _req._validationErrors.push(err)
      else _req._errors.add(null, ...args)
      return err
    }
  }

  return _req
}

// REVISIT: Can we do a regular handler function instead of monky patching?
const _protoHandle = cds.ApplicationService.prototype.handle
const protoHandle = function (req) {
  if (req.event === 'NEW') beforeNew.call(this, req)
  return _protoHandle.call(this, req)
}
const draftHandle = async function (req) {
  if (req.event === 'DISCARD') req.event = 'CANCEL'
  else if (req.event === 'SAVE') {
    req.event = 'draftActivate'
    req.query ??= SELECT.from(req.target, req.data) //> support simple srv.send('SAVE',entity,...)
  }

  // Fast exit for non-draft requests
  // REVISIT: should also start with else, but then this test fails: cds/tests/_runtime/odata/__tests__/integration/draft-custom-handlers.test.js
  if (!req.query) return protoHandle.call(this, req)
  if ($draftParams in req.query) return protoHandle.call(this, req)
  /* prettier-ignore */ if (!(
    // Note: we skip UPSERTs as these might have an additional INSERT
    'SELECT' in req.query ||
    'INSERT' in req.query ||
    'UPDATE' in req.query ||
    'DELETE' in req.query
  )) return protoHandle.call(this, req)
  // TODO: also skip quickly if no draft-enabled entities are involved ?!?
  // TODO: also skip quickly if no isActiveEntity is part of the query ?!?
  // TODO: also skip quickly for CREATE request not from Fiori clients ???

  // rewrite event if necessary
  if (req.protocol && req.target.drafts && req.event in { CREATE: 1, DELETE: 1 }) {
    if (req.event === 'CREATE' && req.data.IsActiveEntity !== true) req.event = 'NEW'
    if (req.event === 'DELETE' && req.data.IsActiveEntity === false) req.event = 'CANCEL'
  }

  const query = _cleansed(req.query, this.model)
  _cleanseParams(req.params, req.target)
  if (req.data) _cleanseParams(req.data, req.target)
  const draftParams = query[$draftParams]

  const run = (query, options = {}) => {
    const _req = _newReq(req, query, draftParams, options)
    return protoHandle.call(this, _req)
  }

  if (req.event === 'READ') {
    if (
      !Object.keys(draftParams).length &&
      !req.query._target.name?.endsWith('DraftAdministrativeData') &&
      !req.query._target.drafts
    ) {
      req.query = query
      return protoHandle.call(this, req)
    }

    // For direct CRUD: Simply forward the read query
    if (
      cds.env.fiori.bypass_draft &&
      query.SELECT.one &&
      !req.query._target.isDraft &&
      draftParams.IsActiveEntity === undefined &&
      !req.target.name.includes('DraftAdministrativeData') // draft admin data requires special handling
    ) {
      req.query = query
      return protoHandle.call(this, req)
    }

    // apply paging and sorting on original query for protocol adapters relying on it
    commonGenericPaging(req)
    commonGenericSorting(req)

    const determineRead = () => {
      // 'draftParams' as filled in '_cleanseQuery'
      const isActiveEntity = draftParams.IsActiveEntity
      const hasDraftEntity = draftParams.HasDraftEntity
      const hasStreaming = _hasStreaming(query.SELECT.columns, query._target)
      const isBinaryDraftCompat = cds.env.features.binary_draft_compat
      const isTargetDraft = req.query._target.name.endsWith('.drafts')
      const inProcessByUserEqNullString = ['not ', 'not null'].includes(
        draftParams.DraftAdministrativeData_InProcessByUser
      )
      const inProcessByUserEqEmptyString = draftParams.DraftAdministrativeData_InProcessByUser === ''
      const isSiblingIsActiveEntityNull = draftParams.SiblingEntity_IsActiveEntity === null

      if (isActiveEntity === false && hasStreaming && !isBinaryDraftCompat) return Read.draftStream
      if (isTargetDraft) return Read.ownDrafts
      if (isActiveEntity === false && isSiblingIsActiveEntityNull) return Read.all
      if (isActiveEntity === true && isSiblingIsActiveEntityNull && inProcessByUserEqNullString)
        return Read.lockedByAnotherUser
      if (isActiveEntity === true && isSiblingIsActiveEntityNull && inProcessByUserEqEmptyString)
        return Read.unsavedChangesByAnotherUser
      if (isActiveEntity === true && hasDraftEntity === false) return Read.unchanged
      if (isActiveEntity === false) return Read.ownDrafts
      return Read.onlyActives
    }

    const read = determineRead()
    const result = await read.bind(this)(run, query)
    return result
  }

  if (req.event === 'draftEdit') req.event = 'EDIT'
  if (req.event === 'draftPrepare' && draftParams.IsActiveEntity)
    cds.error({ status: 400, message: 'Action "draftPrepare" can only be called on the draft entity' })

  // REVISIT: Can't use req.subject here:
  // REVISIT: > Caching in req.subject will yield erroneous result
  // REVISIT: > after replacing req.query by draft adapted query
  let rootEntityName = (
    query.SELECT?.from ||
    query.INSERT?.into ||
    query.UPSERT?.into ||
    query.UPDATE?.entity ||
    query.DELETE?.from
  )?.ref?.[0]
  if (typeof rootEntityName === 'object') rootEntityName = rootEntityName.id
  const rootEntity = this.model.definitions[rootEntityName]

  const newDraftAction =
    cds.env.fiori.draft_new_action && rootEntity['@Common.DraftRoot.NewAction']?.split?.('.').at(-1)
  const shouldHandleNewDraftAction = newDraftAction && req.target.name === rootEntity.name

  const shouldBeConsideredForCreateBypass =
    req.target.drafts &&
    !req.target.isDraft &&
    draftParams.IsActiveEntity !== false &&
    req.data?.IsActiveEntity !== false

  // Create active instance of draft-enabled entity
  // REVISIT: New OData adapter only sets `NEW` for drafts... how to distinguish programmatic modifications?
  if (
    (req.event === 'NEW' && shouldHandleNewDraftAction && req.data.IsActiveEntity !== false) ||
    (req.event === 'NEW' && shouldBeConsideredForCreateBypass && req.target.name !== rootEntity.name) ||
    (req.event === 'CREATE' && shouldBeConsideredForCreateBypass)
  ) {
    if (
      !cds.env.fiori.bypass_draft &&
      req.protocol === 'odata' && // FIXME: lean-draft should never be involved for non-odata requests!
      !('IsActiveEntity' in req.data)
    ) {
      return reject_bypassed_draft(req)
    }

    const queryUsesContainment = !!rootEntity['@Common.DraftRoot.ActivationAction']
    if (!queryUsesContainment) cds.error({ status: 422, message: 'DRAFT_MODIFICATION_ONLY_VIA_ROOT' })

    const isDirectAccess = req.query.INSERT.into.ref?.length === 1
    const data = Array.isArray(req.data) ? [...req.data] : Object.assign({}, req.data) // IsActiveEntity is not enumerable
    const draftsRootRef = _redirectRefToDrafts([query.INSERT.into.ref[0]], this.model)

    let draftRootEntityExists

    // Children: check root entity has no draft
    if (!isDirectAccess) draftRootEntityExists = await SELECT.one([1]).from({ ref: draftsRootRef })

    // Direct access and req.data contains keys: check if root has no draft with that keys
    if (isDirectAccess && _entityKeys(query._target).every(k => k in data)) {
      const keyData = _entityKeys(query._target).reduce((res, k) => {
        res[k] = req.data[k]
        return res
      }, {})
      draftRootEntityExists = await SELECT.one([1]).from({ ref: draftsRootRef }).where(keyData)
    }

    if (draftRootEntityExists) cds.error({ status: 409, message: 'DRAFT_ALREADY_EXISTS' })

    const cqn = INSERT.into(query.INSERT.into).entries(data)
    const result = await run(cqn, { event: 'CREATE' })

    let _data = data
    if (!newDraftAction) {
      if (Array.isArray(data)) _data = data.map(d => ({ ...d, IsActiveEntity: true }))
      else _data = { ...data, IsActiveEntity: true }
      result.forEach(d => (d.IsActiveEntity = true))
      req.data = _data //> make keys available via req.data (as with normal crud)
    } else {
      req.data = Object.assign(req.data, _data) //> make keys available via req.data (as with normal crud)
    }

    return result
  }

  // Prevent creating active entities via drafts
  if (req.event === 'CREATE' && draftParams.IsActiveEntity === false && !req.target.isDraft) {
    cds.error({ status: 403, message: 'ACTIVE_MODIFICATION_VIA_DRAFT' })
  }

  // Handle 'newDraftAction' event if enabled
  if (shouldHandleNewDraftAction && req.event === newDraftAction) {
    if (!req.target.isDraft) req.target = req.target.drafts

    // Rewrite 'newDraftAction' into regular 'NEW' event
    query.SELECT.from.ref = _redirectRefToDrafts(query.SELECT.from.ref, this.model)
    const createNewQuery = INSERT.into(query.SELECT.from).entries(req.data)

    req.event = req._.event = 'NEW'
    req.query = req._.query = createNewQuery

    const innerReq = _newReq(req, createNewQuery, draftParams, { event: 'NEW' })
    await protoHandle.call(this, innerReq)
    const createNewResult = innerReq.data

    req.data = createNewResult
    req.res.status(201)

    const result = await _readAfterDraftAction.call(this, { req, payload: createNewResult, action: 'draftNew' })
    if (result === null) req.res.status(204)
    req.res.set(
      'location',
      '../' + location4(req.target.actives, this, result || { ...createNewResult, IsActiveEntity: false })
    )
    return result
  }

  // Handle draft-only events, that can only ever target entities in draft state
  if (
    (req.event === 'NEW' && (!shouldHandleNewDraftAction || req.data.IsActiveEntity === false)) ||
    req.event === 'CANCEL' ||
    req.event === 'draftPrepare'
  ) {
    if (!req.target.isDraft) req.target = req.target.drafts // COMPAT: also support these events for actives

    if (query.INSERT) query.INSERT.into.ref = _redirectRefToDrafts(query.INSERT.into.ref, this.model)
    else if (query.DELETE) query.DELETE.from.ref = _redirectRefToDrafts(query.DELETE.from.ref, this.model)
    else if (query.SELECT) query.SELECT.from.ref = _redirectRefToDrafts(query.SELECT.from.ref, this.model)

    const _req = _newReq(req, query, draftParams, { event: req.event, headers: req.headers })

    // Do not allow to create active instances via drafts
    if (req.event === 'NEW' && draftParams.IsActiveEntity === false && !_req.target.isDraft) {
      cds.error({ status: 403, message: 'ACTIVE_MODIFICATION_VIA_DRAFT' })
    }

    const result = await protoHandle.call(this, _req)

    req.data = _req.data //> make keys available via req.data (as with normal crud)
    return result
  }

  // Handle 'DELETE' event on entities in active state
  if (req.target.drafts && !req.target.isDraft && req.event === 'DELETE' && draftParams.IsActiveEntity !== false) {
    const draftsRef = _redirectRefToDrafts(query.DELETE.from.ref, this.model)
    const inProcessByUserCol = {
      ref: ['DraftAdministrativeData'],
      expand: [_inProcessByUserXpr(_lock.shiftedNow)]
    }
    const draftQuery = SELECT.one
      .from({ ref: draftsRef })
      .columns([{ ref: ['DraftAdministrativeData_DraftUUID'] }, inProcessByUserCol])
    if (query.DELETE.where) draftQuery.where(query.DELETE.where)

    // Deletion of active instance outside draft tree, no need to check for draft
    const target = cds.infer.target(draftQuery) // FIXME: this should not be neccessary, does it?
    if (!target?.isDraft) {
      await run(query)
      return Object.assign([], { affected: 1 })
    }

    // Deletion of active instance inside draft tree, need to check that no draft exists
    const drafts = []
    const draftsRes = await draftQuery
    if (draftsRes) drafts.push(draftsRes)

    // For hierarchies, check that no sub node exists.
    if (target?.elements?.LimitedDescendantCount) {
      let key
      for (const _key in req.target.keys) {
        if (_key === 'IsActiveEntity') continue
        key = _key // only single key supported
      }
      // We must only do this for recursive _composition_ children.
      // For recursive _association_ children, app developers must deal with dangling pointers themselves.
      const _recursiveComposition = target => {
        for (const _comp in target.compositions) {
          if (target.compositions[_comp]['@odata.draft.ignore']) {
            return target.compositions[_comp]
          }
        }
      }
      const recursiveComposition = _recursiveComposition(req.target)
      if (recursiveComposition) {
        let uplinkName
        for (const key in req.target) {
          if (key.match(/@Aggregation\.RecursiveHierarchy\s*#.*\.ParentNavigationProperty/)) {
            uplinkName = req.target[key]['=']
            break
          }
        }
        const keyVal = req.query.DELETE.from.ref[0].where?.[2]?.val
        if (keyVal === undefined) cds.error({ status: 400, message: 'Deletion not supported' })
        // We must select actives and check for corresponding drafts (drafts themselve don't necessarily form a hierarchy)
        const recursiveQ = SELECT.from(req.target).columns(key)
        recursiveQ.SELECT.recurse = {
          ref: [uplinkName],
          where: [{ func: 'DistanceTo', args: [{ val: keyVal }, { val: null }] }]
        }
        const recursives = await recursiveQ
        if (recursives.length) {
          const recursiveDrafts = await SELECT.from(req.target.drafts)
            .columns(inProcessByUserCol)
            .where(Read.whereIn(req.target, recursives))
          drafts.push(...recursiveDrafts)
        }
      }
    }

    for (const draft of drafts) {
      const inProcessByUser = draft?.DraftAdministrativeData?.InProcessByUser
      if (!cds.context.user._is_privileged && inProcessByUser && inProcessByUser !== cds.context.user.id)
        cds.error({ status: 403, message: 'DRAFT_LOCKED_BY_ANOTHER_USER', args: [inProcessByUser] })
      else cds.error({ status: 403, message: 'DRAFT_ACTIVE_DELETE_FORBIDDEN_DRAFT_EXISTS' })
    }
    await run(query)
    return Object.assign([], { affected: 1 })
  }

  // Handle 'draftActivate' event
  if (req.event === 'draftActivate') {
    LOG.debug('activate draft')

    if (req.query.SELECT.from.ref.length > 1 || draftParams.IsActiveEntity === true) {
      cds.error({
        status: 400,
        message: 'Action "draftActivate" can only be called on the root draft entity'
      })
    }

    if (req.target._etag && !req.headers['if-match'] && !req.headers['if-none-match']) {
      cds.error(428)
    }

    const columns = expandStarStar(req.target.drafts, true)

    const draftRef = _redirectRefToDrafts(query.SELECT.from.ref, this.model)
    const draftQuery = SELECT.one
      .from({ ref: draftRef })
      .columns(columns)
      .columns([
        // Will automatically select 'IsActiveEntity' as key column
        { ref: ['HasActiveEntity'] },
        { ref: ['DraftAdministrativeData_DraftUUID'] },
        {
          ref: ['DraftAdministrativeData'],
          expand: [
            { ref: ['InProcessByUser'] },
            ...(IS_PERSISTED_DRAFT_MESSAGES_ENABLED ? [{ ref: ['DraftMessages'] }] : [])
          ]
        }
      ])
      .where(query.SELECT.where)
    const res = await run(draftQuery)

    if (!res) {
      const _etagValidationType = req.headers['if-match']
        ? 'if-match'
        : req.headers['if-none-match']
          ? 'if-none-match'
          : undefined
      cds.error(_etagValidationType ? { status: 412 } : { status: 404, message: 'DRAFT_NOT_EXISTING' })
    }
    if (!cds.context.user._is_privileged && res.DraftAdministrativeData?.InProcessByUser !== cds.context.user.id) {
      cds.error({
        status: 403,
        message: 'DRAFT_LOCKED_BY_ANOTHER_USER',
        args: [res.DraftAdministrativeData?.InProcessByUser]
      })
    }

    // Remove draft artefacts from persistedDraft entry
    const DraftAdministrativeData_DraftUUID = res.DraftAdministrativeData_DraftUUID
    const persistedDraftMessages = res.DraftAdministrativeData?.DraftMessages || []
    delete res.DraftAdministrativeData_DraftUUID
    delete res.DraftAdministrativeData
    const HasActiveEntity = res.HasActiveEntity
    delete res.HasActiveEntity

    if (
      _hasStreaming(draftQuery.SELECT.columns, draftQuery._target, true) &&
      !cds.env.features.binary_draft_compat &&
      !cds.env.fiori.move_media_data_in_db
    ) {
      await _removeEmptyStreams(res)
    }

    // First run the handlers as they might need access to DraftAdministrativeData or the draft entities
    const activesRef = _redirectRefToActives(query.SELECT.from.ref, this.model)

    // Upsert draft into active, not considering media data columns
    const upsertQuery = HasActiveEntity
      ? UPDATE({ ref: activesRef }).data(res).where(query.SELECT.where)
      : INSERT.into({ ref: activesRef }).entries(res)
    const upsertOptions = { headers: Object.assign({}, req.headers, { 'if-match': '*' }) }

    const _req = _newReq(req, upsertQuery, draftParams, upsertOptions)

    if (IS_PERSISTED_DRAFT_MESSAGES_ENABLED) {
      _req.on('failed', async error => {
        if (!error && !_req.errors?.length) {
          LOG.debug('Draft activation failed without error information: Skip update of DraftMessages.')
          return
        }
        const errors = []
        if (_req.errors?.length) {
          // Need to clone errors to avoid side effects on original error objects
          errors.push(..._req.errors.map(e => ({ ...e })))
        } else {
          // NOTE: this branch is for on-commit errors, which don't end up in req.errors
          // IMPORTANT: copy error objects to avoid side effects on original error
          if (typeof error === 'object') errors.push({ ...error })
          if (error.details) errors.push(...error.details.map(e => ({ ...e })))
        }
        const nextDraftMessages = compileUpdatedDraftMessages(errors, persistedDraftMessages, _req.data || {}, draftRef)
        await cds.tx(async () => {
          await UPDATE('DRAFT.DraftAdministrativeData')
            .set({ DraftMessages: nextDraftMessages })
            .where({ DraftUUID: DraftAdministrativeData_DraftUUID })
        })
      })
    }

    const result = await protoHandle.call(this, _req).catch(err => {
      // block pop-up in fiori draft activation flow
      if (err.code === 'MULTIPLE_ERRORS' || err.message === 'MULTIPLE_ERRORS') err.target ??= 'in'
      throw err
    })

    // REVISIT: Remove feature flag dependency
    if (cds.env.fiori.move_media_data_in_db) {
      // Move cds.LargeBinary data from draft to active
      const updateMediaDataQueries = getUpdateFromSelectQueries(req.target, draftRef, activesRef)
      await _promiseAll(updateMediaDataQueries)
    }

    // Delete draft artefacts
    await _promiseAll([
      DELETE.from({ ref: draftRef }).where(query.SELECT.where),
      DELETE.from('DRAFT.DraftAdministrativeData').where({ DraftUUID: DraftAdministrativeData_DraftUUID })
    ])

    if (req.res) {
      // status code must be set in handler to allow overriding for FE V2
      // REVISIT: needs reworking for new adapter, especially re $batch
      if (!HasActiveEntity) req.res.status(201)

      const read_result = await _readAfterDraftAction.bind(this)({
        req,
        payload: res,
        action: 'draftActivate'
      })
      req.res.set('location', '../' + location4(req.target, this, read_result || { ...res, IsActiveEntity: true }))

      if (read_result == null) req.res.status(204)

      return read_result
    }

    return Object.assign(result, { IsActiveEntity: true })
  }

  // Handle regular custom actions on entities in draft state
  if (req.target.actions?.[req.event] && !(req.event in WELL_KNOWN_EVENTS) && draftParams.IsActiveEntity === false) {
    if (query.SELECT?.from?.ref) query.SELECT.from.ref = _redirectRefToDrafts(query.SELECT.from.ref, this.model)

    // Check if the draft is locked by another user
    const rootQuery = query.clone()
    rootQuery.SELECT.columns = [{ ref: ['DraftAdministrativeData'], expand: [{ ref: ['InProcessByUser'] }] }]
    rootQuery.SELECT.one = true
    rootQuery.SELECT.from = { ref: [query.SELECT.from.ref[0]] }
    const root = await cds.run(rootQuery)

    if (!root) cds.error(404)
    if (root.DraftAdministrativeData?.InProcessByUser !== cds.context.user.id) {
      cds.error({
        status: 403,
        message: 'DRAFT_LOCKED_BY_ANOTHER_USER',
        args: [root.DraftAdministrativeData.InProcessByUser]
      })
    }

    const _req = _newReq(req, query, draftParams, { event: req.event })
    const result = await protoHandle.call(this, _req)

    return result
  }

  // Handle 'UPDATE' events on entities in draft or active state
  if (req.event === 'PATCH' || (req.event === 'UPDATE' && req.target.drafts)) {
    // also delete `IsActiveEntity` for references
    const _rmIsActiveEntity = (data, target) => {
      delete data.IsActiveEntity
      for (const assoc in target.associations) {
        const val = data[assoc]
        if (val && typeof val === 'object') {
          const _target = req.target.associations[assoc]._target
          if (Array.isArray(val)) {
            val.forEach(v => _rmIsActiveEntity(v, _target))
          } else {
            _rmIsActiveEntity(val, _target)
          }
        }
      }
    }
    _rmIsActiveEntity(req.data, req.target)

    // REVISIT: This should allow `IsActiveEntity: false` to be passed in the body
    // REVISIT: > Enabling this would re-establish symmetry with CREATE
    if (draftParams.IsActiveEntity === false) {
      LOG.debug('patch draft')

      if (req.target?.name.endsWith('DraftAdministrativeData')) cds.error(405)

      const draftsRef = _redirectRefToDrafts(query.UPDATE.entity.ref, this.model)
      const res = await SELECT.one.from({ ref: draftsRef }).columns('DraftAdministrativeData_DraftUUID', {
        ref: ['DraftAdministrativeData'],
        expand: [
          { ref: ['InProcessByUser'] },
          ...(IS_PERSISTED_DRAFT_MESSAGES_ENABLED ? [{ ref: ['DraftMessages'] }] : [])
        ]
      })

      if (!res) cds.error(404)
      if (!cds.context.user._is_privileged && res.DraftAdministrativeData?.InProcessByUser !== cds.context.user.id) {
        cds.error({
          status: 403,
          message: 'DRAFT_LOCKED_BY_ANOTHER_USER',
          args: [res.DraftAdministrativeData?.InProcessByUser]
        })
      }

      const innerQuery = UPDATE({ ref: draftsRef }).data(req.data)
      const innerReq = _newReq(req, innerQuery, draftParams, {})
      await protoHandle.call(this, innerReq).catch(error => {
        // > This prevents thrown req.errors from being added to 'sap-messages'
        // > Downgraded req.error will add to req.messages, regardless of whether the error is thrown
        // > Unless we prevent it here, the response will contain the error in both body and header
        // > Downgrading is only required for PATCH, to prevent a rollback in case validation fails
        if (req.messages?.length) req.messages = req.messages.filter(m => m !== error)
        throw req.error(error)
      })

      const nextDraftAdminData = {
        InProcessByUser: req.user.id,
        LastChangedByUser: req.user.id,
        LastChangeDateTime: new Date()
      }

      if (IS_PERSISTED_DRAFT_MESSAGES_ENABLED) {
        nextDraftAdminData.DraftMessages = compileUpdatedDraftMessages(
          req._validationErrors ?? [],
          res.DraftAdministrativeData?.DraftMessages ?? [],
          req.data ?? {},
          draftsRef
        )
      }

      await UPDATE('DRAFT.DraftAdministrativeData')
        .data(nextDraftAdminData)
        .where({ DraftUUID: res.DraftAdministrativeData_DraftUUID })

      req.data.IsActiveEntity = false
      return Object.assign([], { affected: 1 })
    }

    LOG.debug('patch active')

    if (
      req.protocol === 'odata' && // FIXME: lean-draft should never be involved for non-odata requests!
      !cds.env.fiori.bypass_draft &&
      !req.target['@odata.draft.bypass']
    )
      return reject_bypassed_draft(req)

    const entityRef = query.UPDATE.entity.ref

    if (!this.model.definitions[entityRef[0].id || entityRef[0]]['@Common.DraftRoot.ActivationAction']) {
      cds.error({ status: 422, message: 'DRAFT_MODIFICATION_ONLY_VIA_ROOT' })
    }

    const draftsRef = _redirectRefToDrafts(entityRef, this.model)
    const draftsQuery = SELECT.one([1]).from({ ref: [draftsRef[0]] })
    if (query.UPDATE.where) draftsQuery.where(query.UPDATE.where)
    const hasDraft = !!(await draftsQuery)
    if (hasDraft) cds.error({ status: 409, message: 'DRAFT_ALREADY_EXISTS' })

    await run(query)
    return Object.assign([], { affected: 1 })
  }

  req.query = query

  return protoHandle.call(this, req)
}

// REVISIT: It's not optimal to first calculate the whole result array and only later
//          delete unrequested properties. However, as a first step, we do it that way,
//          especially since the current db driver always adds those fields.
//          Once we switch to the new driver, we'll adapt it.
const _requested = (result, query) => {
  const originalQuery = query[$original]
  if (!result || !originalQuery) return result
  const all = ['HasActiveEntity', 'HasDraftEntity']

  const ignoredCols = new Set(all.concat('DraftAdministrativeData'))
  const _isODataV2 = cds.context?.http?.req?.headers?.['x-cds-odata-version'] === 'v2'
  if (!_isODataV2) ignoredCols.add('DraftAdministrativeData_DraftUUID')
  for (const col of originalQuery.SELECT.columns || ['*']) {
    const name = col.as || col.ref?.[0] || col
    if (all.includes(name) || name === 'DraftAdministrativeData' || name === 'DraftAdministrativeData_DraftUUID')
      ignoredCols.delete(name)
    if (name === '*') all.forEach(c => ignoredCols.delete(c))
  }
  if (!ignoredCols.size) return result
  const resArray = Array.isArray(result) ? result : [result]
  for (const row of resArray) {
    for (const ignoredCol of ignoredCols) delete row[ignoredCol]
  }
  return result
}

const _readDraftStream = (draftStream, activeCQN, property) =>
  Readable.from(
    (async function* () {
      let isActive = true
      this._stream = draftStream
      for await (const chunk of draftStream) {
        isActive = false
        yield chunk
      }

      if (isActive) {
        const active = (await activeCQN)?.[property]
        if (active) {
          for await (const chunk of active) {
            yield chunk
          }
        }
      }
    })()
  )

// REVISIT: HanaLobStream of @sap/hana-client cannot read chunks with "for await" - hangs
const _readDraftStreamHanaClient = async (draftStream, activeCQN, property) =>
  Readable.from(
    (async function* () {
      let isActive = true
      const pth = new PassThrough()
      draftStream.pipe(pth)
      for await (const chunk of pth) {
        isActive = false
        yield chunk
      }

      if (isActive) {
        const active = (await activeCQN)?.[property]
        if (active) {
          const pth = new PassThrough()
          active.pipe(pth)
          for await (const chunk of pth) {
            yield chunk
          }
        }
      }
    })()
  )

const { count_as_string } = cds.env.features

const Read = {
  onlyActives: async function (run, query, { ignoreDrafts } = {}) {
    LOG.debug('List Editing Status: Only Active')

    if (_isCount(query)) return run(query)

    if (query._target.name.endsWith('.DraftAdministrativeData')) {
      // DraftAdministrativeData is only accessible via drafts
      if (query.SELECT.from.ref?.length === 1) {
        cds.error({ status: 400, message: 'INVALID_DRAFT_REQUEST' })
      }

      return run(query._drafts)
    }

    if (!query._target._isDraftEnabled) return run(query)

    if (
      !query.SELECT.groupBy &&
      query.SELECT.columns &&
      !query.SELECT.columns.some(c => c === '*') &&
      !query.SELECT.columns.some(c => c.func && AGGREGATION_FUNCTIONS.includes(c.func))
    ) {
      const keys = _entityKeys(query._target)
      for (const key of keys) {
        if (!query.SELECT.columns.some(c => c.ref?.[0] === key)) query.SELECT.columns.push({ ref: [key] })
      }
    }

    // Query active entity instances
    const actives = await run(query)

    if (!actives || (Array.isArray(actives) && !actives.length)) return actives
    if (!query._target.drafts) return actives

    // Query corresponding drafts, if not explicitly ignored
    const drafts = !ignoreDrafts ? await this.run(Read.complementaryDrafts(query, actives)) : []

    Read.merge(query._target, actives, drafts, (row, other) => {
      if (other) {
        if ('DraftAdministrativeData' in other) row.DraftAdministrativeData = other.DraftAdministrativeData
        if ('DraftAdministrativeData_DraftUUID' in other)
          row.DraftAdministrativeData_DraftUUID = other.DraftAdministrativeData_DraftUUID
        Object.assign(row, { HasActiveEntity: false, HasDraftEntity: true })
      } else
        Object.assign(row, {
          HasActiveEntity: false,
          HasDraftEntity: false,
          DraftAdministrativeData: null,
          DraftAdministrativeData_DraftUUID: null
        })
      _fillIsActiveEntity(row, true, query._target)
    })

    return _requested(actives, query)
  },

  unchanged: async function (run, query) {
    LOG.debug('List Editing Status: Unchanged')

    const draftsQuery = query._drafts
    if (!draftsQuery) cds.error({ status: 400, message: 'INVALID_DRAFT_REQUEST' }) // only via drafts
    draftsQuery.SELECT.count = undefined
    draftsQuery.SELECT.orderBy = undefined
    draftsQuery.SELECT.limit = null
    draftsQuery.SELECT.columns = _entityKeys(query._target).map(k => ({ ref: [k] }))

    const drafts = await draftsQuery.where({ HasActiveEntity: true })
    const res = await Read.onlyActives(run, query.where(Read.whereNotIn(query._target, drafts)), {
      ignoreDrafts: true
    })
    return _requested(res, query)
  },

  ownDrafts: async function (run, query) {
    LOG.debug('List Editing Status: Own Draft')

    if (!query._drafts) cds.error({ status: 400, message: 'INVALID_DRAFT_REQUEST' }) // only via drafts

    // read active from draft
    if (!query._drafts._target?.name.endsWith('.drafts')) {
      const result = await run(query._drafts)

      // active entity is draft enabled, draft columns have to be removed
      if (query._drafts._target?.drafts) {
        Read.merge(query._drafts._target, result, [], row => {
          delete row.IsActiveEntity
          delete row.HasDraftEntity
          delete row.HasActiveEntity
          delete row.DraftAdministrativeData_DraftUUID
        })
      }
      return result
    }

    const selectedColumnNames = query._drafts.SELECT.columns?.map(c => c.ref?.[0] || c) || ['*']
    const isAllKeysSelected =
      selectedColumnNames.includes('*') ||
      Object.keys(query._drafts._target.keys).every(k => selectedColumnNames.includes(k))

    let txModel
    if (IS_PERSISTED_DRAFT_MESSAGES_ENABLED && isAllKeysSelected) {
      // Replace selection of 'DraftMessages' with the proper path expression

      query._drafts.SELECT.columns = [
        ...(query._drafts.SELECT.columns ?? ['*']).filter(c => c.ref?.[0] !== 'DraftMessages'),
        { ref: ['DraftAdministrativeData', 'DraftMessages'], as: 'DraftMessages' }
      ]

      txModel = cds.context.tx.model
    }

    const draftsQuery = query._drafts.where(
      { ref: ['DraftAdministrativeData', 'InProcessByUser'] },
      '=',
      cds.context.user.id
    )

    const drafts = await run(draftsQuery)
    Read.merge(query._target, drafts, [], row => {
      Object.assign(row, {
        HasDraftEntity: false
      })
      _fillIsActiveEntity(row, false, query._drafts._target)

      if (IS_PERSISTED_DRAFT_MESSAGES_ENABLED && row.DraftMessages?.length) {
        // Based on the query for own drafts, compile the ref of a query matching
        // the format produced by cds.odata.parse to compare against message prefixes

        const queryRootEntity = txModel.definitions[draftsQuery.SELECT.from.ref[0].id || draftsQuery.SELECT.from.ref[0]]
        const queryPrefixRef = _extractPrefixRef(draftsQuery.SELECT.from.ref, queryRootEntity)

        if (queryPrefixRef.length > 1) {
          let targetRef = queryPrefixRef[queryPrefixRef.length - 1]
          if (typeof targetRef === 'string') {
            // Construct key from model info and result data

            queryPrefixRef[queryPrefixRef.length - 1] = targetRef = { id: targetRef, where: [] }

            // This repliactes the strucutally equivalent logic from _compileUpdatedDraftMessages
            // > This is necessary to enable filtering for messages realted to a newly created entity
            // > Since readAfterRide will put key info into a filter rather than into the path
            for (const k in draftsQuery._target.actives.keys) {
              const key = draftsQuery._target.actives.keys[k]
              let v = row[key.name]
              if (v === undefined)
                if (key.name === 'IsActiveEntity') v = false
                else continue
              if (v instanceof Buffer) v = v.toString('base64') //> convert binary keys to base64
              if (targetRef.where.length > 0) targetRef.where.push('and')
              targetRef.where.push({ ref: [key.name] }, '=', { val: v })
            }
          }
        }

        // Reduce persisted draft messages to the set of those that are relevant for this result row:
        // Specification: https://sapui5.hana.ondemand.com/#/topic/fbe1cb5613cf4a40a841750bf813238e:~:text=Lifecycle%20Management%20for%20State%20Messages,-The%20lifecycle%20management
        const filteredDraftMessages = row.DraftMessages.reduce((acc, msg) => {
          const msgPrefixRef = cds.odata.parse(msg.prefix).SELECT.from.ref
          if (queryPrefixRef.length > msgPrefixRef.length) return acc

          // TODO: This seems excessive ... how to compare more efficiently?
          const queryPrefixUrl = cds.odata.urlify(
            { SELECT: { from: { ref: queryPrefixRef } } },
            { kind: 'odata-v4', model: txModel }
          ).path
          const msgPrefixUrl = cds.odata.urlify(
            { SELECT: { from: { ref: msgPrefixRef } } },
            { kind: 'odata-v4', model: txModel }
          ).path

          if (!msgPrefixUrl.startsWith(queryPrefixUrl)) return acc

          msg.target = `/${msg.prefix}/${msg.target}`
          if (msg.additionalTargets?.length)
            msg.additionalTargets = msg.additionalTargets.map(additionalTarget => `/${msg.prefix}/${additionalTarget}`)

          delete msg.prefix

          acc.push(msg)
          return acc
        }, [])

        const { locale } = cds.context
        row.DraftMessages = filteredDraftMessages.map(e => {
          // eslint-disable-next-line no-unused-vars
          const { status, args, _i18n, ...cleansed } = odata.localized(e, locale)
          return cleansed
        })
      }
    })

    return _requested(drafts, query)
  },

  all: async function (run, query) {
    LOG.debug('List Editing Status: All')

    if (!query._drafts) return []

    query._drafts.SELECT.count = false
    query._drafts.SELECT.limit = null // we need all entries for the keys to properly select actives (count)
    const isCount = _isCount(query._drafts)
    if (isCount) {
      query._drafts.SELECT.columns = _entityKeys(query._target).map(k => ({ ref: [k] }))
    }
    if (!query._drafts.SELECT.columns) query._drafts.SELECT.columns = ['*']
    if (!query._drafts.SELECT.columns.some(c => c.ref?.[0] === 'HasActiveEntity')) {
      query._drafts.SELECT.columns.push({ ref: ['HasActiveEntity'] })
    }

    const orderByExpr = query.SELECT.orderBy
    const getOrderByColumns = columns => {
      const selectAll = columns === undefined || columns.includes('*')
      const queryColumns = !selectAll && columns && columns.map(column => column.as || column?.ref?.[0]).filter(c => c)
      const newColumns = []

      for (const column of orderByExpr) {
        if (selectAll || !queryColumns.includes(column.ref.join('_'))) {
          if (column.ref.length === 1 && selectAll) continue
          const columnClone = { ...column }
          delete columnClone.sort
          columnClone.as = columnClone.ref.join('_')
          newColumns.push(columnClone)
        }
      }

      return newColumns
    }

    let orderByDraftColumns
    if (orderByExpr) {
      orderByDraftColumns = getOrderByColumns(query._drafts.SELECT.columns)
      if (orderByDraftColumns.length) query._drafts.SELECT.columns.push(...orderByDraftColumns)
    }

    const ownDrafts = await run(
      query._drafts.where({ ref: ['DraftAdministrativeData', 'InProcessByUser'] }, '=', cds.context.user.id)
    )
    const draftLength = ownDrafts.length
    const limit = query.SELECT.limit?.rows?.val ?? getPageSize(query._target).max
    const offset = query.SELECT.limit?.offset?.val ?? 0
    query.SELECT.limit = {
      rows: { val: limit + draftLength }, // virtual limit
      offset: { val: Math.max(0, offset - draftLength) } // virtual offset
    }

    let orderByColumns
    if (orderByExpr) {
      orderByColumns = getOrderByColumns(query.SELECT.columns)
      if (orderByColumns.length) {
        query.SELECT.columns = query.SELECT.columns ?? ['*']
        query.SELECT.columns.push(...orderByColumns)
      }
    }

    const queryElements = query.elements
    const actives = await run(query.where(Read.whereNotIn(query._target, ownDrafts)))
    const removeColumns = (columns, toRemoveCols) => {
      if (!toRemoveCols) return
      for (const c of toRemoveCols) columns.forEach((column, index) => c.as === column.as && columns.splice(index, 1))
    }
    removeColumns(query._drafts.SELECT.columns, orderByDraftColumns)
    removeColumns(query.SELECT.columns, orderByColumns)

    const ownNewDrafts = []
    const ownEditDrafts = []
    for (const draft of ownDrafts) {
      if (draft.HasActiveEntity) ownEditDrafts.push(draft)
      else ownNewDrafts.push(draft)
    }

    let $count = isCount ? actives[0]?.$count : actives?.$count
    $count = $count != null ? Number($count) : 0
    $count += ownDrafts.length

    if (isCount) return { $count: count_as_string ? `${$count}` : $count }

    Read.merge(query._target, ownDrafts, [], row => {
      Object.assign(row, { HasDraftEntity: false })
      _fillIsActiveEntity(row, false, query._drafts._target)
    })
    const otherEditDrafts = actives?.length ? await this.run(Read.complementaryDrafts(query, actives)) : []
    Read.merge(query._target, actives, otherEditDrafts, (row, other) => {
      if (other) {
        Object.assign(row, {
          HasDraftEntity: true,
          HasActiveEntity: false,
          DraftAdministrativeData_DraftUUID: other.DraftAdministrativeData_DraftUUID,
          DraftAdministrativeData: other.DraftAdministrativeData
        })
      } else {
        Object.assign(row, {
          HasDraftEntity: false,
          HasActiveEntity: false,
          DraftAdministrativeData_DraftUUID: null,
          DraftAdministrativeData: null
        })
      }
      _fillIsActiveEntity(row, true, query._target)
    })
    const resultSet =
      actives.length > 0 && ownDrafts.length === 0
        ? actives
        : ownDrafts.length > 0 && actives.length === 0
          ? ownDrafts
          : [...ownDrafts, ...actives]

    // runtime sort required
    if (orderByExpr && ownDrafts.length > 0 && actives.length > 0) {
      const locale = cds.context.locale?.replaceAll('_', '-')
      const collatorMap = new Map()
      const elementNamesToSort = orderByExpr.map(orderByExp => orderByExp.ref.join('_'))

      for (const elementName of elementNamesToSort) {
        const element = queryElements[elementName] ?? query._target.elements[elementName] // The latter is needed for CDS orderBy statements
        if (!element) continue

        let collatorOptions

        switch (element.type) {
          case 'cds.Integer':
          case 'cds.UInt8':
          case 'cds.Int16':
          case 'cds.Int32':
          case 'cds.Integer64':
          case 'cds.Int64':
          case 'cds.Decimal':
          case 'cds.DecimalFloat':
          case 'cds.Double':
            collatorOptions = numericCollator
            break

          default:
            collatorOptions = emptyObject
        }

        const collator = Intl.Collator(locale, collatorOptions)
        collatorMap.set(elementName, collator)
      }

      const getSortFn =
        (index = 0) =>
        (entityA, entityB) => {
          const orderBy = orderByExpr[index]
          const elementName = elementNamesToSort[index]
          const collator = collatorMap.get(elementName)
          const valueA = entityA[elementName]
          const valueB = entityB[elementName]

          if (valueA == null && valueB == null) {
            // continue to next sort criterion
            if (index + 1 < orderByExpr.length) return getSortFn(index + 1)(entityA, entityB)
            return 0
          }

          const nullsFirst = orderBy.nulls ? orderBy.nulls.toLowerCase() === 'first' : orderBy.sort === 'asc'
          if (valueA == null) return nullsFirst ? -1 : 1
          if (valueB == null) return nullsFirst ? 1 : -1

          const diff = collator.compare(valueA, valueB)

          if (diff === 0 && index + 1 < orderByExpr.length) return getSortFn(index + 1)(entityA, entityB)
          if (orderBy.sort === 'desc') return diff * -1
          return diff
        }

      resultSet.sort(getSortFn())
    }

    let virtualOffset = offset - draftLength
    virtualOffset = virtualOffset > 0 ? draftLength : draftLength + virtualOffset
    const pageResultSet = _filterResultSet(resultSet, limit, virtualOffset)
    if (query.SELECT.count) {
      $count += ownDrafts.$count != null ? Number(ownDrafts.$count) : 0
      pageResultSet.$count = count_as_string ? `${$count}` : $count
    }
    return _requested(pageResultSet, query)
  },

  activesFromDrafts: async function (run, query, { isLocked = true }) {
    const draftsQuery = query._drafts
    if (!draftsQuery) cds.error({ status: 400, message: 'INVALID_DRAFT_REQUEST' }) // only via drafts

    const additionalCols = draftsQuery.SELECT.columns
      ? draftsQuery.SELECT.columns.filter(
          c => c.ref && ['DraftAdministrativeData', 'DraftAdministrativeData_DraftUUID'].includes(c.ref[0])
        )
      : [{ ref: ['DraftAdministrativeData_DraftUUID'] }]
    draftsQuery.SELECT.columns = _entityKeys(query._target)
      .map(k => ({ ref: [k] }))
      .concat(additionalCols)
    draftsQuery.where({
      HasActiveEntity: true,
      'DraftAdministrativeData.InProcessByUser': { '!=': cds.context.user.id },
      'DraftAdministrativeData.LastChangeDateTime': {
        [isLocked ? '>' : '<']: _lock.shiftedNow
      }
    })
    const drafts = await draftsQuery
    const actives = drafts.length
      ? await run(query.where(Read.whereIn(query._target, drafts)))
      : Object.assign([], { $count: count_as_string ? '0' : 0 })
    Read.merge(query._target, actives, drafts, (row, other) => {
      if (other) Object.assign(row, other, { HasDraftEntity: true, HasActiveEntity: false })
      else Object.assign({ HasDraftEntity: false, HasActiveEntity: false })
      _fillIsActiveEntity(row, true, query._target)
    })
    return _requested(actives, query)
  },

  unsavedChangesByAnotherUser: async function (run, query) {
    LOG.debug('List Editing Status: Unsaved Changes by Another User')

    return Read.activesFromDrafts(run, query, { isLocked: false })
  },

  lockedByAnotherUser: async function (run, query) {
    LOG.debug('List Editing Status: Locked by Another User')

    return Read.activesFromDrafts(run, query, { isLocked: true })
  },

  whereNotIn: (target, data) => Read.whereIn(target, data, true),

  whereIn: (target, data, not = false) => {
    const keys = _entityKeys(target)
    const dataArray = data ? (Array.isArray(data) ? data : [data]) : []
    if (not && !dataArray.length) return []
    if (keys.length === 1) {
      // For single keys, make it nicer (without unnecessary lists)
      const key = keys[0]
      const left = { ref: [key] }
      const op = not ? ['not', 'in'] : ['in']
      const right = { list: dataArray.map(r => ({ val: r[key] })) }
      return [left, ...op, right]
    } else {
      const left = { list: keys.map(k => ({ ref: [k] })) }
      const op = not ? ['not', 'in'] : ['in']
      const right = { list: dataArray.map(r => ({ list: keys.map(k => ({ val: r[k] })) })) }
      return [left, ...op, right]
    }
  },

  complementaryDrafts: (query, _actives) => {
    const actives = Array.isArray(_actives) ? _actives : [_actives]
    if (!actives.length) return []
    const drafts = SELECT.from(query._target.drafts)
    drafts[$draftParams] = query[$draftParams]
    drafts.SELECT.where = Read.whereIn(query._target, actives)
    const newColumns = _entityKeys(query._target).map(k => ({ ref: [k] }))
    const queryDrafts = query._drafts
    if (queryDrafts) {
      if (
        !queryDrafts.SELECT.columns ||
        queryDrafts.SELECT.columns.some(c => c === '*' || c.ref?.[0] === 'DraftAdministrativeData_DraftUUID')
      )
        newColumns.push({ ref: ['DraftAdministrativeData_DraftUUID'] })
      const draftAdmin = queryDrafts.SELECT.columns?.find(c => c.ref?.[0] === 'DraftAdministrativeData')
      if (draftAdmin) newColumns.push(draftAdmin)
    }
    drafts.SELECT.columns = newColumns
    return drafts
  },

  draftStream: async (run, query) => {
    // read from draft
    const result = await Read.ownDrafts(run, query)
    if (!Array.isArray(result)) {
      for (let key in result) {
        if (result[key] instanceof Readable) {
          result[key] =
            result[key].constructor.name === 'HanaLobStream'
              ? await _readDraftStreamHanaClient(result[key], query, key)
              : _readDraftStream(result[key], query, key)
        }
      }
    }

    return result
  },

  _makeArray: data => (Array.isArray(data) ? data : data ? [data] : []),

  _index: (target, data) => {
    // Indexes the data for fast key access
    const dataArray = Read._makeArray(data)
    if (!dataArray.length) return
    const hash = row =>
      _entityKeys(target)
        .map(k => row[k])
        .reduce((res, curr) => res + '|$|' + curr, '')
    const hashMap = new Map()
    for (const row of dataArray) hashMap.set(hash(row), row)
    return { hashMap, hash }
  },

  // Calls `cb` for each entry of data with a potential counterpart in otherData
  merge: (target, data, otherData, cb) => {
    const dataArray = Read._makeArray(data)
    if (!dataArray.length) return

    const index = Read._index(target, otherData)
    for (const row of dataArray) {
      const other = index?.hashMap.get(index.hash(row))
      cb(row, other)
    }
  },

  // Deletes entries of data with a counterpart in otherData
  delete: (target, data, otherData) => {
    if (!Array.isArray(data) || !data.length) return

    const index = Read._index(target, otherData)
    let i = data.length
    while (i--) {
      if (index?.hashMap.get(index.hash(data[i]))) data.splice(i, 1)
    }
  }
}

function _cleanseParams(params, target) {
  if (!target?.drafts) return
  if (Array.isArray(params)) {
    for (const param of params) _cleanseParams(param, target)
    return
  }
  if (typeof params === 'object') {
    for (const key in params) {
      if (key === 'IsActiveEntity') {
        const value = params[key]
        delete params[key]
        Object.defineProperty(params, key, { value, enumerable: false, writeable: true, configurable: true })
      }
    }
  }
}

function _cleanseCols(columns, elements, target) {
  // TODO: sometimes target is undefined
  if (!target || typeof columns?.filter !== 'function') return columns
  const filtered = target?.drafts ? columns.filter(c => !elements.has(c.ref?.[0])) : columns
  return filtered.map(c => {
    if (c.expand && c.ref) {
      return { ...c, expand: _cleanseCols(c.expand, elements, target.elements[c.ref[0]]?._target) }
    }
    return c
  })
}

let DRAFT_ADMIN_ELEMENTS
/**
 * Creates a clone of the query, cleanses and collects all draft parameters into DRAFT_PARAMS.
 */
function _cleansed(query, model) {
  const draftParams = {} //> used to collect draft filter criteria
  const q = _cleanseQuery(query, draftParams, model)
  if (query.SELECT) {
    const getDrafts = () => {
      // could just clone `query` but the latter is ruined by database layer
      const draftsQuery = _cleanseQuery(query, {}, model)

      // set the target to null to ensure cds.infer(...) correctly infer the
      // target after query modifications
      Object.defineProperty(draftsQuery, '_target', { value: null, configurable: true, writable: true })
      let draftSelect = draftsQuery.SELECT
      let querySelect = query.SELECT

      // in the $apply scenario, only the most inner nested SELECT data structure must be cleansed
      while (draftSelect.from.SELECT) {
        // set the target to null to ensure cds.infer(...) correctly infer the
        // target after query modifications
        if (draftSelect.from._target)
          Object.defineProperty(draftSelect.from, '_target', { value: null, configurable: true, writable: true })
        draftSelect = draftSelect.from.SELECT
        querySelect = querySelect.from.SELECT
      }

      if (!draftSelect.from.ref) return // invalid draft request

      const [root, ...tail] = draftSelect.from.ref
      const draft = model.definitions[root.id || root].drafts
      if (!draft) return
      draftSelect.from = {
        ref: [root.id ? { ...root, id: draft.name } : draft.name, ...tail]
      }
      cds.infer.target(draftsQuery)

      // draftsQuery._target = draftsQuery._target?.drafts || draftsQuery._target
      if (querySelect.columns && query._target.drafts) {
        if (draftsQuery._target.isDraft)
          draftSelect.columns = _cleanseCols(querySelect.columns, REDUCED_DRAFT_ELEMENTS, draft)
        else draftSelect.columns = _cleanseCols(querySelect.columns, DRAFT_ELEMENTS, draft)
      }

      if (querySelect.where && query._target.drafts) {
        if (draftsQuery._target.isDraft)
          draftSelect.where = _cleanseWhere(querySelect.where, {}, DRAFT_ELEMENTS_WITHOUT_HASACTIVE)
        else draftSelect.where = _cleanseWhere(querySelect.where, {}, DRAFT_ELEMENTS)
      }

      if (querySelect.orderBy && query._target.drafts) {
        if (draftsQuery._target.isDraft)
          draftSelect.orderBy = _cleanseWhere(querySelect.orderBy, {}, REDUCED_DRAFT_ELEMENTS)
        else draftSelect.orderBy = _cleanseWhere(querySelect.orderBy, {}, DRAFT_ELEMENTS)
      }

      if (draftsQuery._target.name.endsWith('.DraftAdministrativeData')) {
        draftSelect.columns = _tweakAdminCols(draftSelect.columns)
      } else if (draftsQuery._target?.name.endsWith('.drafts')) {
        draftSelect.columns = _tweakAdminExpand(draftSelect.columns)
      }

      draftsQuery[$draftParams] = draftParams
      Object.defineProperty(q, '_drafts', { value: draftsQuery })
      return draftsQuery
    }

    Object.defineProperty(q, '_drafts', {
      configurable: true,
      get() {
        return getDrafts()
      }
    })
  }

  q[$draftParams] = draftParams
  q[$original] = query
  return q

  function _cleanseQuery(query, draftParams, model) {
    const target = query._target
    const q = cds.ql.clone(query)

    if (q.SELECT?.from.SELECT) q.SELECT.from = _cleanseQuery(q.SELECT?.from, draftParams, model)
    const ref =
      q.SELECT?.from.SELECT?.from.ref ||
      q.SELECT?.from.ref ||
      q.UPDATE?.entity.ref ||
      q.INSERT?.into.ref ||
      q.DELETE?.from.ref
    const cqn = q.SELECT || q.UPDATE || q.INSERT || q.DELETE

    if (ref) {
      let entity
      const cleansedRef = ref.map(r => {
        entity = (entity && entity.elements[r.id || r]._target) || model.definitions[r.id || r]
        if (!entity?.drafts) return r
        return r.where ? { ...r, where: _cleanseWhere(r.where, draftParams, DRAFT_ELEMENTS) } : r
      })
      if (q.SELECT) q.SELECT.from = q.SELECT.from.SELECT ? q.SELECT.from : { ...q.SELECT.from, ref: cleansedRef }
      else if (q.DELETE) q.DELETE.from = { ...q.DELETE.from, ref: cleansedRef }
      else if (q.UPDATE) q.UPDATE.entity = { ...q.UPDATE.entity, ref: cleansedRef }
      else if (q.INSERT) q.INSERT.into = { ...q.INSERT.into, ref: cleansedRef }

      // This only works for simple cases of `SiblingEntity`, e.g. `root(ID=1,IsActiveEntity=false)/SiblingEntity`
      // , check if there are more complicated use cases
      const siblingIdx = cleansedRef.findIndex(r => r === 'SiblingEntity')
      if (siblingIdx !== -1) {
        cleansedRef.splice(siblingIdx, 1)
        draftParams.IsActiveEntity = !draftParams.IsActiveEntity
      }
    }

    if (target.drafts && cqn.where) cqn.where = _cleanseWhere(cqn.where, draftParams, DRAFT_ELEMENTS)
    if (target.drafts && cqn.orderBy) cqn.orderBy = _cleanseCols(cqn.orderBy, DRAFT_ELEMENTS, target) // allowed to reuse
    if (cqn.columns) cqn.columns = _cleanseCols(cqn.columns, DRAFT_ELEMENTS, target)
    return q
  }

  function _tweakAdminExpand(columns) {
    if (!columns) return columns
    return columns.map(col => {
      if (col.ref?.[0] === 'DraftAdministrativeData') {
        return { ...col, expand: _tweakAdminCols(col.expand) }
      }
      return col
    })
  }

  function _tweakAdminCols(columns) {
    if (!DRAFT_ADMIN_ELEMENTS) {
      DRAFT_ADMIN_ELEMENTS = []
      for (const key in cds.model.definitions['DRAFT.DraftAdministrativeData'].elements) DRAFT_ADMIN_ELEMENTS.push(key)
    }

    if (!columns || columns.some(c => c === '*')) columns = DRAFT_ADMIN_ELEMENTS.map(k => ({ ref: [k] }))
    return columns.map(col => {
      const name = col.ref?.[0]
      if (!name) return col
      switch (name) {
        case 'DraftAdministrativeData':
          return { ...col, expand: _tweakAdminCols(col.expand) }
        case 'DraftIsCreatedByMe':
          return {
            xpr: [
              'case',
              'when',
              { ref: ['CreatedByUser'] },
              '=',
              { val: cds.context.user.id },
              'then',
              'true',
              'else',
              'false',
              'end'
            ],
            as: 'DraftIsCreatedByMe',
            cast: { type: 'cds.Boolean' }
          }
        case 'InProcessByUser':
          return _inProcessByUserXpr(_lock.shiftedNow)
        case 'DraftIsProcessedByMe':
          return {
            xpr: [
              'case',
              'when',
              { ref: ['InProcessByUser'] },
              '=',
              { val: cds.context.user.id },
              'and',
              { ref: ['LastChangeDateTime'] },
              '>',
              { val: _lock.shiftedNow },
              'then',
              'true',
              'else',
              'false',
              'end'
            ],
            as: 'DraftIsProcessedByMe',
            cast: { type: 'cds.Boolean' }
          }
        default:
          return col
      }
    })
  }

  function _cleanseWhere(xpr, draftParams, ignoredElements) {
    const cleansed = []
    for (let i = 0; i < xpr.length; ++i) {
      let x = xpr[i]
      const e = x.ref?.[0]
      if (ignoredElements.has(e) && !xpr[i + 2]) {
        continue
      }
      if (ignoredElements.has(e) && xpr[i + 2]) {
        let { val } = xpr[i + 2]
        const param = x.ref.join('_')
        // outer-most parameters win
        if (draftParams[param] === undefined)
          draftParams[param] = xpr[i + 1] === '!=' ? (typeof val === 'boolean' ? !val : 'not ' + val) : val
        i += 2
        const last = cleansed[cleansed.length - 1]
        if (last === 'and' || last === 'or') cleansed.pop()
        continue
      }
      if (x.xpr) {
        x = { xpr: _cleanseWhere(x.xpr, draftParams, ignoredElements) }
        if (!x.xpr) {
          i += 1
          continue
        }
      }
      cleansed.push(x)
    }
    const first = cleansed[0]
    if (first === 'and' || first === 'or') cleansed.shift()
    const last = cleansed[cleansed.length - 1]
    if (last === 'and' || last === 'or') cleansed.pop()
    if (cleansed.length) return cleansed
  }
}

// REVISIT: This function is better defined on DB layer
function expandStarStar(target, draftActivate, recursion = new Map()) {
  const columns = []

  for (const el in target.elements) {
    const element = target.elements[el]

    // Skip calculated elements
    if (draftActivate && element.value) continue

    // Make sure column is releveant & add it to output
    const isDraftInfo = DRAFT_ELEMENTS.has(el)
    const isGenerated = draftActivate && !!(element['@cds.on.insert'] || element['@cds.on.update'])
    const isLargeBinary = cds.env.fiori.move_media_data_in_db && draftActivate && element._type === 'cds.LargeBinary'
    const isSkippedType = element.isAssociation || isLargeBinary
    if (!isDraftInfo && !isGenerated && !isSkippedType && !element['@odata.draft.skip']) columns.push({ ref: [el] })

    // Skip children where draft is explicitly disabled
    if (!element.isComposition || element._target['@odata.draft.enabled'] === false || element['@odata.draft.ignore'])
      continue // happens for texts if not @fiori.draft.enabled

    // Make sure recursion depth is not exceeded
    const cacheKey = target.name + ':' + el
    let cache = recursion.get(cacheKey) ?? 0
    recursion.set(cacheKey, ++cache)
    if (cache >= MAX_RECURSION_DEPTH) continue

    // Recurse
    const expandedColumns = expandStarStar(element._target, draftActivate, recursion)

    // Unpack recursion result
    if (expandedColumns.length) columns.push({ ref: [el], expand: expandedColumns })
  }

  return columns
}

function beforeNew(req) {
  if (!req.target.isDraft) return

  function _cleanseData(data, target) {
    if (!data) return
    delete data.IsActiveEntity
    if (!target) return data

    // Also support deep insertions
    for (const key in data) {
      if (!target.elements[key]) return data
      if (data[key] && target.elements[key].isAssociation) delete data[key].IsActiveEntity
      if (!target.elements[key].isComposition) continue
      if (Array.isArray(data[key])) data[key] = data[key].map(v => _cleanseData(v, target.elements[key]._target))
      else if (typeof data[key] === 'object') data[key] = _cleanseData(data[key], target.elements[key]._target)
    }

    return data
  }

  _cleanseData(req.data, req.target)
}

async function onNew(req, next) {
  if (!req.target.isDraft) return next?.()

  LOG.debug('new draft')

  if (req.target.actives['@Capabilities.InsertRestrictions.Insertable'] === false || req.target.actives['@readonly'])
    cds.error(405)

  //> support simple srv.send('NEW',entity,...)
  req.query ??= INSERT.into(req.subject).entries(req.data || {})

  // Only allowed for pseudo draft roots (entities with this action)
  const isDirectAccess = req.query.INSERT.into.ref?.length === 1
  if (isDirectAccess && !req.target.actives['@Common.DraftRoot.ActivationAction'])
    cds.error({ status: 422, message: 'DRAFT_MODIFICATION_ONLY_VIA_ROOT' })

  _cleanUpOldDrafts(this, req.tenant)

  let DraftUUID
  let DraftMessages = []
  let nextDraftMessages = []
  if (isDirectAccess) DraftUUID = cds.utils.uuid()
  else {
    const rootData = await SELECT.one(req.query.INSERT.into.ref[0].id)
      .columns([
        { ref: ['DraftAdministrativeData_DraftUUID'] },
        {
          ref: ['DraftAdministrativeData'],
          expand: [
            { ref: ['InProcessByUser'] },
            ...(IS_PERSISTED_DRAFT_MESSAGES_ENABLED ? [{ ref: ['DraftMessages'] }] : [])
          ]
        }
      ])
      .where(req.query.INSERT.into.ref[0].where)

    if (!rootData) cds.error(404)
    if (!cds.context.user._is_privileged && rootData.DraftAdministrativeData?.InProcessByUser !== req.user.id)
      cds.error({
        status: 403,
        message: 'DRAFT_LOCKED_BY_ANOTHER_USER',
        args: [rootData.DraftAdministrativeData.InProcessByUser]
      })

    DraftUUID = rootData.DraftAdministrativeData_DraftUUID
    DraftMessages = rootData.DraftAdministrativeData?.DraftMessages || []
  }

  const timestamp = cds.context.timestamp.toISOString() // REVISIT: toISOString should be done on db layer
  const draftData = _createNewDraftData(req.query.INSERT.entries[0], req.target, DraftUUID)
  const draftCQN = INSERT.into(req.subject).entries(draftData)

  const insertReq = _newReq(req, draftCQN, req.query[$draftParams], {})
  await this.dispatch(insertReq)

  if (IS_PERSISTED_DRAFT_MESSAGES_ENABLED) {
    nextDraftMessages = compileUpdatedDraftMessages(
      req._validationErrors ?? [],
      DraftMessages,
      draftData,
      req.query.INSERT.into.ref
    )
  }

  const adminDataCQN = isDirectAccess
    ? INSERT.into('DRAFT.DraftAdministrativeData').entries({
        DraftUUID,
        CreationDateTime: timestamp,
        CreatedByUser: req.user.id,
        LastChangeDateTime: timestamp,
        LastChangedByUser: req.user.id,
        DraftIsCreatedByMe: true, // Dummy values
        DraftIsProcessedByMe: true, // Dummy values
        InProcessByUser: req.user.id,
        ...(IS_PERSISTED_DRAFT_MESSAGES_ENABLED ? { DraftMessages: nextDraftMessages } : {})
      })
    : UPDATE('DRAFT.DraftAdministrativeData')
        .data({
          InProcessByUser: req.user.id,
          LastChangedByUser: req.user.id,
          LastChangeDateTime: timestamp,
          ...(IS_PERSISTED_DRAFT_MESSAGES_ENABLED ? { DraftMessages: nextDraftMessages } : {})
        })
        .where({ DraftUUID })

  await adminDataCQN

  req.data = { ...draftData, IsActiveEntity: false }
  // prettier-ignore
  const pk = Object.keys(req.target.keys).reduce((acc, cur) => ((acc[cur] = req.data[cur]), acc), { IsActiveEntity: false })
  return Object.assign([pk], { affected: 1 })
}

async function onEdit(req, next) {
  if (req.target.isDraft) return next?.()

  LOG.debug('edit active')

  req.query ??= SELECT.from(req.target, req.data).where({ IsActiveEntity: true }) //> support simple srv.send('EDIT',entity,...)

  // REVISIT: can draftParams in the edit case ever be undefined or other than IsActiveEntity=true ?
  const draftParams = req.query[$draftParams] || { IsActiveEntity: true }
  if (req.query.SELECT.from.ref.length > 1 || draftParams.IsActiveEntity === false) {
    cds.error({
      status: 400,
      message: 'Action "draftEdit" can only be called on the root active entity'
    })
  }

  if (
    req.target['@Capabilities.UpdateRestrictions.Updatable'] === false ||
    req.target['@insertonly'] ||
    req.target['@readonly']
  ) {
    cds.error({ status: 405 })
  }

  _cleanUpOldDrafts(this, req.tenant)

  const DraftUUID = cds.utils.uuid()

  // REVISIT: Later optimization if datasource === db: INSERT FROM SELECT
  const cols = expandStarStar(req.target, false)
  const _addDraftColumns = (target, columns) => {
    if (target.drafts) {
      columns.push({ val: true, as: 'HasActiveEntity' })
      columns.push({ val: DraftUUID, as: 'DraftAdministrativeData_DraftUUID' })
    }
    for (const col of columns) {
      if (col.expand) {
        const el = target.elements[col.ref[0]]
        _addDraftColumns(el._target, col.expand)
      }
    }
  }

  _addDraftColumns(req.target, cols)

  const draftsRef = _redirectRefToDrafts(req.query.SELECT.from.ref, this.model)
  const existingDraft = SELECT.one({ ref: draftsRef }).columns({
    ref: ['DraftAdministrativeData'],
    expand: [_inProcessByUserXpr(_lock.shiftedNow)]
  })

  // prevent service to check for own user
  existingDraft[$draftParams] = draftParams

  const selectActiveCQN = SELECT.one.from({ ref: req.query.SELECT.from.ref }).columns(cols)
  selectActiveCQN.SELECT.localized = false

  let res, draft

  // Ensure exclusive access to the record of the active entity by applying a lock,
  // which effectively prevents the creation or overwriting of duplicate draft entities.
  // This lock mechanism enforces a strict processing order for active entities,
  // allowing only one entity to be worked on at any given time.
  // By using .forUpdate() with a wait value of 0, we immediately lock the record,
  // ensuring there is no waiting time for other users attempting to edit the same record
  // concurrently.
  if (this._datasource === cds.db) {
    const keys = _entityKeys(req.target)
    const keyData = _getKeyData(keys, req.query.SELECT.from.ref[0].where)
    const rootWhere = keys.reduce((res, key) => {
      res[key] = keyData[key]
      return res
    }, {})
    const transition = cds.db.resolve.transitions(req.query)

    // gets the underlying target entity, as record locking can't be
    // applied to localized views
    const lockTarget = transition.target
    const lockWhere =
      transition.mapping.size === 0
        ? rootWhere
        : (() => {
            const whereKeys = Object.keys(rootWhere)
            const w = {}
            whereKeys.forEach(key => {
              const mappedKey = transition.mapping.get(key)
              const lockKey = mappedKey ? mappedKey.ref[0] : key
              w[lockKey] = rootWhere[key]
            })
            return w
          })()

    const activeLockCQN = SELECT.from(lockTarget, [1]).where(lockWhere).forUpdate({ wait: 0 })
    activeLockCQN.SELECT.localized = false
    activeLockCQN[$draftParams] = draftParams

    try {
      await activeLockCQN
    } catch (error) {
      LOG._debug && LOG.debug('Failed to acquire database lock:', error)
      const draft = await existingDraft
      cds.error({ status: 409, message: draft ? 'DRAFT_ALREADY_EXISTS' : 'ENTITY_LOCKED' })
    }

    const cqns = [
      cds.env.fiori.read_actives_from_db ? cds.db.run(selectActiveCQN) : this.run(selectActiveCQN),
      existingDraft
    ]

    ;[res, draft] = await _promiseAll(cqns)
  } else {
    const activeLockCQN = SELECT.from({ ref: req.query.SELECT.from.ref }, [1]).forUpdate({ wait: 0 })
    activeLockCQN.SELECT.localized = false
    activeLockCQN[$draftParams] = draftParams

    // Locking the underlying database table is effective only when the database is not
    // hosted on an external service. This is because the active data might be stored in
    // a separate system.
    try {
      await activeLockCQN
    } catch (error) {
      LOG._debug && LOG.debug('Failed to acquire database lock:', error)
    }

    ;[res, draft] = await _promiseAll([
      // REVISIT: inofficial compat flag just in case it breaks something -> do not document
      cds.env.fiori.read_actives_from_db ? cds.db.run(selectActiveCQN) : this.run(selectActiveCQN),
      // no user check must be done here...
      existingDraft
    ])
  }

  if (!res) cds.error(404)

  const preserveChanges = req.data?.PreserveChanges
  const inProcessByUser = draft?.DraftAdministrativeData?.InProcessByUser

  if (draft) {
    if (inProcessByUser || preserveChanges) cds.error({ status: 409, message: 'DRAFT_ALREADY_EXISTS' })
    const keys = {}
    for (const key in req.target.drafts.keys) keys[key] = res[key]
    await _promiseAll([
      DELETE.from('DRAFT.DraftAdministrativeData').where({ DraftUUID }),
      DELETE.from(req.target.drafts).where(keys)
    ])
  }

  if (!cds.env.features.binary_draft_compat) _replaceStreams(res)

  const timestamp = cds.context.timestamp.toISOString() // REVISIT: toISOString should be done on db layer
  await INSERT.into('DRAFT.DraftAdministrativeData').entries({
    DraftUUID,
    CreationDateTime: timestamp,
    CreatedByUser: req.user.id,
    LastChangeDateTime: timestamp,
    LastChangedByUser: req.user.id,
    DraftIsCreatedByMe: true, // Dummy values
    DraftIsProcessedByMe: true, // Dummy values
    InProcessByUser: req.user.id
  })

  // is set to `null` on srv layer
  res.DraftAdministrativeData_DraftUUID = DraftUUID
  res.HasActiveEntity = true
  delete res.DraftAdministrativeData
  // change to db run
  await INSERT.into(req.target.drafts).entries(res)

  if (req.res) {
    // status code must be set in handler to allow overriding for FE V2
    // REVISIT: needs reworking for new adapter, especially re $batch
    req.res.status(201)

    const read_result = await _readAfterDraftAction.bind(this)({
      req,
      payload: res,
      action: 'draftEdit'
    })
    req.res.set('location', '../' + location4(req.target, this, read_result || { ...res, IsActiveEntity: false }))

    if (read_result == null) req.res.status(204)

    return read_result
  } else {
    return { ...res, IsActiveEntity: false } // REVISIT: Flatten?
  }
}

async function onCancel(req, next) {
  if (!req.target.isDraft) return next?.()
  LOG.debug('delete draft')

  req.query ??= DELETE(req.target, req.data) //> support simple srv.send('CANCEL',entity,...)
  const draftParams = req.query[$draftParams] || { IsActiveEntity: false }

  const expandedDraftAdminElements = [_inProcessByUserXpr(_lock.shiftedNow)]
  if (IS_PERSISTED_DRAFT_MESSAGES_ENABLED) expandedDraftAdminElements.push({ ref: ['DraftMessages'] })

  const draftQuery = SELECT.one.from({ ref: req.query.DELETE.from.ref }).columns([
    'DraftAdministrativeData_DraftUUID',
    {
      ref: ['DraftAdministrativeData'],
      expand: expandedDraftAdminElements
    }
  ])
  if (req._etagValidationClause && draftParams.IsActiveEntity === false) draftQuery.where(req._etagValidationClause)

  const draft = await draftQuery

  if (!draft) cds.error({ status: req._etagValidationType ? 412 : 404 })

  const processByUser = draft.DraftAdministrativeData?.InProcessByUser
  if (!cds.context.user._is_privileged && processByUser && processByUser !== cds.context.user.id)
    cds.error({ status: 403, message: 'DRAFT_LOCKED_BY_ANOTHER_USER', args: [processByUser] })

  const deleteQuery = DELETE.from({ ref: req.query.DELETE.from.ref })
  const deleteReq = _newReq(req, deleteQuery, draftParams, {})
  const queries = [this.dispatch(deleteReq)]

  if (req.target['@Common.DraftRoot.ActivationAction']) {
    // The root entity is being deleted and draft admin data can be deleted

    queries.push(
      DELETE.from('DRAFT.DraftAdministrativeData').where({
        DraftUUID: draft.DraftAdministrativeData_DraftUUID
      })
    )
  } else {
    // A child entity is being deleted and draft admin data must be updated

    const nextDraftAdminData = {
      InProcessByUser: cds.context.user.id,
      LastChangedByUser: cds.context.user.id,
      LastChangeDateTime: cds.context.timestamp.toISOString()
    }

    if (IS_PERSISTED_DRAFT_MESSAGES_ENABLED) {
      // Determine persisted draft messages that relate to the deleted child entity

      const queryRootEntity = this.model.definitions[req.query.DELETE.from.ref[0].id || req.query.DELETE.from.ref[0]]

      if (queryRootEntity['@Common.DraftRoot.ActivationAction']) {
        // The DELETE query uses containment & we can compile a target prefix
        // > This allows us to only remove those messages that target the delted child

        const prefixRef = _extractPrefixRef(req.query.DELETE.from.ref, queryRootEntity)
        const messageTargetPrefix = cds.odata.urlify(
          { SELECT: { from: { ref: prefixRef } } },
          { kind: 'odata-v4', model: req.context.tx.model }
        ).path

        // Remove those draft messages whose prefix matches the deleted child entity
        nextDraftAdminData.DraftMessages = (draft?.DraftAdministrativeData?.DraftMessages || []).filter(
          msg => !msg.prefix.startsWith(messageTargetPrefix)
        )
      } else {
        // The query does not use containment & we can not compile a target prefix
        // > Best ew can do is to clear all persisted messages

        nextDraftAdminData.DraftMessages = []
      }
    }

    const updateDraftAdminDataQuery = UPDATE('DRAFT.DraftAdministrativeData')
      .data(nextDraftAdminData)
      .where({ DraftUUID: draft.DraftAdministrativeData_DraftUUID })

    queries.push(updateDraftAdminDataQuery)
  }

  await _promiseAll(queries)

  return Object.assign([], { affected: 1 })
}

async function onPrepare(req, next) {
  if (!req.target.isDraft) return next?.()
  LOG.debug('prepare draft')

  const draftParams = req.query[$draftParams]
  if (req.query.SELECT.from.ref.length > 1 || draftParams.IsActiveEntity !== false) {
    cds.error({
      status: 400,
      message: 'Action "draftPrepare" can only be called on the root draft entity'
    })
  }

  const selectedCols = ['*']
  if (req.target.actions.draftPrepare.returns.type === req.target.actives.name) {
    selectedCols.push(...(req.query.SELECT.columns ?? []))
    if (selectedCols.length > 1) selectedCols.shift()
    const draftMsgColIdx = selectedCols.findIndex(c => c.ref?.[0] === 'DraftMessages')
    if (draftMsgColIdx >= 0) {
      selectedCols.splice(draftMsgColIdx)
      selectedCols.push(...cds.ql.columns`DraftAdministrativeData.DraftMessages as DraftMessages`)
    }
  }

  const draftQuery = SELECT.one
    .from(req.target)
    .columns([...selectedCols, cds.ql.expand(cds.ql.ref`DraftAdministrativeData`, cds.ql.columns`InProcessByUser`)])
    .where(req.subject.ref[0].where)

  draftQuery[$draftParams] = draftParams

  const data = await draftQuery

  if (!data) cds.error(404)
  if (!cds.context.user._is_privileged && data.DraftAdministrativeData?.InProcessByUser !== req.user.id)
    cds.error({
      status: 403,
      message: 'DRAFT_LOCKED_BY_ANOTHER_USER',
      args: [data.DraftAdministrativeData?.InProcessByUser]
    })

  if (getPreferReturnHeader(req) === 'minimal') return null

  delete data.DraftAdministrativeData
  if (data && req.headers?.['x-cds-odata-version'] !== 'v2') {
    // The result must not include DraftAdministrativeData_DraftUUID
    // > in for OData V4, however, a value is required in OData V2
    delete data.DraftAdministrativeData_DraftUUID
  }

  return {
    ...data,
    IsActiveEntity: false,
    HasDraftEntity: false,
    HasActiveEntity: data.HasActiveEntity || false
  }
}

const _readAfterDraftAction = async function ({ req, payload, action }) {
  if (getPreferReturnHeader(req) === 'minimal') return null

  const entity = action === 'draftActivate' ? req.target : req.target.drafts

  // read after write with query options
  const keys = {}
  for (let key of entity.keys) {
    if (key.name === 'IsActiveEntity' || key.isAssociation || key.virtual) continue
    keys[key.name] = payload[key.name]
  }
  if (action === 'draftActivate') keys.IsActiveEntity = true

  let read = SELECT.one.from(entity, keys)
  if (req.req?.query.$select || req.req?.query.$expand) {
    const queryOptions = []
    if (req.req.query.$select) queryOptions.push(`$select=${req.req.query.$select}`)
    if (req.req.query.$expand) queryOptions.push(`$expand=${req.req.query.$expand}`)
    read.columns(cds.odata.parse(`/X?${queryOptions.join('&')}`).SELECT.columns)
    // ensure keys are always selected
    Object.keys(keys).forEach(key => {
      if (!read.SELECT.columns.some(c => c.ref?.[0] === key)) read.SELECT.columns.push({ ref: [key] })
    })
    // also ensure selection of etag columns
    addEtagColumns(read.SELECT.columns, entity)
    handleStreamProperties(entity, read.SELECT.columns, this.model)
  }

  try {
    const read_result = await this.run(read)
    // result must not include DraftAdministrativeData_DraftUUID for plain v4 usage, however required for odata-v2
    if (read_result && req.headers?.['x-cds-odata-version'] !== 'v2') {
      delete read_result.DraftAdministrativeData_DraftUUID
    }
    return read_result
  } catch (err) {
    if (!(Number(err.code) in { 401: 1, 403: 1, 404: 1, 405: 1 })) throw err
    // it's important to return null if one of the above accepted errors occurs
    return null
  }
}

module.exports = cds.service.impl(function () {
  if (!this.entities?.DraftAdministrativeData) return

  // REVISIT: don't pollute services... -> do we really need this?
  Object.defineProperty(this, '_datasource', { value: cds.db })

  // Extend the AppService's API by draft specific functions
  this.new = (draft, key) => ({
    then: (r, e) => this.send('NEW', draft, key).then(r, e),
    for: key => this.send('EDIT', typeof draft === 'string' ? draft.replace(/\.drafts$/, '') : draft.actives, key)
  })
  this.edit = (active, key) => this.send('EDIT', active, key)
  this.save = (draft, key) => this.send('SAVE', draft, key)
  this.cancel = (draft, key) => this.send('CANCEL', draft, key)
  this.discard = (draft, key) => this.send('DISCARD', draft, key)

  // Override the AppService's handle function
  this.handle = !cds.env.features.legacy_srv_results
    ? draftHandle
    : async function (req) {
        if (req.protocol?.match(/odata/) && req.event in { NEW: 1 }) req._.readAfterWrite = true

        const res = await draftHandle.call(this, req)
        return Array.isArray(res) && 'affected' in res ? req.data : res
      }

  this.on('NEW', '*', onNew.bind(this))
  this.on('EDIT', '*', onEdit.bind(this))
  this.on('CANCEL', '*', onCancel.bind(this))
  this.on('draftPrepare', '*', onPrepare.bind(this))
})
module.exports.compileUpdatedDraftMessages = compileUpdatedDraftMessages
