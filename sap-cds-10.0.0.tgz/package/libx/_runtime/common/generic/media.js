module.exports = function () {
  const media_entities = {}
  for (let each of this.entities) {
    if (_is_irrelevant(each)) continue
    for (let e in each.elements) {
      const ref = _media_type_ref4(each.elements[e])
      if (!ref) continue
      let entry = (media_entities[each.name] = { ref, element: e })
      if (each.drafts) media_entities[each.drafts.name] = entry
    }
  }
  if (!Object.keys(media_entities).length) return () => {} // no media entities => nothing to handle
  return function handle_media_type(req) {
    let entry = media_entities[req.target.name]
    if (entry && entry.element in req.data && _is_field_request(req)) {
      let content_type = req.req?.get('content-type')
      if (!content_type || content_type.includes('multipart')) return
      else req.data[entry.ref] = content_type
    }
  }
}

const _media_type_ref4 = media_element => media_element['@Core.MediaType']?.['=']
const _is_irrelevant = d => d['@readonly'] || d.name.endsWith('.texts')
const _is_field_request = req => req.req?._query?._propertyAccess
