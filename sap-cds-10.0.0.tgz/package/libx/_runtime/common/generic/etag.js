const cds = require('../../cds')
const { SELECT } = cds.ql

const { addEtagColumns } = require('../utils/etag')

const _parseHeaderEtagValue = value => {
  return value?.split(',').map(str => {
    let result = str.trim()
    if (result === '*') return result
    if (result.startsWith('W/')) result = result.substring(2)
    return result.startsWith('"') && result.endsWith('"') ? result.substring(1, result.length - 1) : null
  })
}

const _getValidationStmt = (ifMatchEtags, ifNoneMatchEtags, req) => {
  const etagElement = req.target._etag

  const cond = []
  if (ifMatchEtags) {
    if (ifMatchEtags.includes('*')) return true
    // HANA does not allow malformed time values in prepared statements
    if (etagElement.type === 'cds.Timestamp' || etagElement.type === 'cds.DateTime') {
      ifMatchEtags = ifMatchEtags.filter(val => new Date(val).toString() !== 'Invalid Date')
      if (!ifMatchEtags.length) return false
    }

    cond.push({ ref: [etagElement.name] })
    if (ifMatchEtags.length === 1) cond.push('=', { val: ifMatchEtags[0] })
    else cond.push('in', { list: ifMatchEtags.map(val => ({ val })) })
  } else {
    if (req.event !== 'READ' && ifNoneMatchEtags.includes('*')) return false
    // if a malformed time value is present, it cannot match -> precondition true
    if (
      (etagElement.type === 'cds.Timestamp' || etagElement.type === 'cds.DateTime') &&
      ifNoneMatchEtags.some(val => new Date(val).toString() === 'Invalid Date')
    ) {
      return true
    }

    if (req.event !== 'READ') {
      cond.push({ ref: [etagElement.name] })
      if (ifNoneMatchEtags.length === 1) cond.push('!=', { val: ifNoneMatchEtags[0] })
      else cond.push('not', 'in', { list: ifNoneMatchEtags.map(val => ({ val })) })
    }
  }
  if (!cond.length) return true

  const select = SELECT.from(req.subject).columns(1)
  select._doNotResolve = true // tell resolveView to leave this select alone
  return select.where(cond)
}

async function handle_etags(req) {
  // Currently, etag is only supported for OData
  if (req.protocol !== 'odata') return

  // Only handle if target has etag element
  if (!req.target?._etag) return

  // for backwards compatibility w.r.t. ETag generation if type UUID
  if (req.target._etag.isUUID && req.event in { CREATE: 1, UPDATE: 1, NEW: 1 }) {
    req.data[req.target._etag.name] = cds.utils.uuid()
  }

  // Only handle if event is a CRUD event or a bound action
  if (req.event in { READ: 1, UPDATE: 1, DELETE: 1, EDIT: 1, CANCEL: 1 } || req.target.actions?.[req.event]) {
    // automatically add etag columns if not already there
    if (req.query.SELECT) addEtagColumns(req.query.SELECT.columns, req.target)

    // No etag handling for collection reads
    if (req.event === 'READ' && !req.query.SELECT.one) return

    // get etag-related headers
    const ifMatch = _parseHeaderEtagValue(req.headers['if-match'])
    const ifNoneMatch = _parseHeaderEtagValue(req.headers['if-none-match'])
    if (!ifMatch && !ifNoneMatch) {
      if (req.event === 'READ') return // > ok and nothing more to do
      req.reject(428) // > on writes, an etag must be provided
    }

    // get select for validation
    const validationStmt = _getValidationStmt(ifMatch, ifNoneMatch, req, this.model)
    if (validationStmt === false) return req.reject(412) // never true -> reject
    if (validationStmt === true) return // wildcard -> nothing to do

    // bound action or CRUD?
    if (req.event === 'EDIT' || req.target.actions?.[req.event]) {
      await cds.db?.run(validationStmt).then(result => result.length || req.reject(412))
    } else if (validationStmt) {
      // add where clause for validation
      const validationClause = ['exists', validationStmt]
      req.query.where(validationClause)
      // HACK for current draft impl // REVISIT: which is really bad
      req._etagValidationClause = validationClause
      req._etagValidationType = ifMatch ? 'if-match' : 'if-none-match'
    }
  }
}

module.exports = () => handle_etags
