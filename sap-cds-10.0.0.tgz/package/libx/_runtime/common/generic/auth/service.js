const { getRejectReason } = require('./utils')

exports.roles4 = srv => {
  const { '@requires': roles } = srv.definition
  if (!roles?.length) return
  if (roles.includes('any')) return
  if (roles.includes('internal-user')) return
  else return Array.isArray(roles) ? roles : [roles]
}

exports.check = (roles, req, def) => {
  if (req.user._is_privileged) return //> skipping all checks for privileged users
  if (req.user._is_anonymous) return req.reject(401) //> give a chance to login
  if (!roles.some(role => req.user.has(role)))
    return req.reject(403, {
      internal: getRejectReason(req, '@requires', def)
    })
}
