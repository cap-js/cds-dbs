const MAX_WAITING_TIME = 1480000

function expBkfRnd(x) {
  return x > 18 ? MAX_WAITING_TIME : (Math.pow(1.5, x) + Math.random()) * 1000
}

function expBkfFix(x) {
  return x > 18 ? MAX_WAITING_TIME : (Math.pow(1.5, x) - 1) * 1000
}

module.exports = {
  expBkfRnd,
  expBkfFix
}
