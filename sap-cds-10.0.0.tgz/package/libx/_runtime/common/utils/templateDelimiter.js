module.exports = '|$|'
