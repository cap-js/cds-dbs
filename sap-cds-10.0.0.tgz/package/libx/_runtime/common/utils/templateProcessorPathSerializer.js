const segmentKeySerializer = pathSegmentInfo => {
  const { key: tKey, row, elements, draftKeys } = pathSegmentInfo
  let keyNames = pathSegmentInfo.keyNames

  const keyValuePairs = keyNames
    .map(key => {
      const keyValue = row[key] ?? draftKeys?.[key]
      if (keyValue == null) return

      let formattedValue

      switch (elements[key].type) {
        case 'cds.String':
          formattedValue = `'${keyValue}'`
          break

        case 'cds.Binary':
          if (Buffer.isBuffer(keyValue)) formattedValue = keyValue.toString('base64')
          formattedValue = `binary'${formattedValue}'`
          break

        default:
          formattedValue = keyValue
          break
      }

      return `${key}=${formattedValue}`
    })
    .filter(c => c)

  const keyValuePairsSerialized = keyValuePairs.join(',')
  const pathSegment = `${tKey}(${keyValuePairsSerialized})`
  return pathSegment
}

const segmentIndexSerializer = pathSegmentInfo => {
  const { key: tKey, rowIndex } = pathSegmentInfo
  return `${tKey}[${rowIndex}]`
}

const templatePathSerializer = (elementName, pathSegmentsInfo, serializeWithIndices = false) => {
  const pathSegments = pathSegmentsInfo.map(pathSegmentInfo => {
    if (typeof pathSegmentInfo === 'string') return pathSegmentInfo
    if (serializeWithIndices) return segmentIndexSerializer(pathSegmentInfo)
    return segmentKeySerializer(pathSegmentInfo)
  })
  const path = `${pathSegments.join('/')}${pathSegments.length ? '/' : ''}${elementName}`
  return path
}

module.exports = templatePathSerializer
