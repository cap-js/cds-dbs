const { foreignKey4 } = require('../utils/foreignKeyPropagations')

const _getCommonFieldControl = e => {
  const cfr = e['@Common.FieldControl']
  return cfr && cfr['#']
}

const _isReadOnly = e => {
  return (
    e['@readonly'] ||
    e['@cds.on.update'] ||
    e['@cds.on.insert'] ||
    e['@Core.Computed'] ||
    e['@Common.FieldControl.ReadOnly'] ||
    e['@FieldControl.ReadOnly'] ||
    _getCommonFieldControl(e) === 'ReadOnly'
  )
}

// NOTE: Please only add things which are relevant to _any_ type,
// use specialized types otherwise (entity, Association, ...).
module.exports = class {
  get _isStructured() {
    return this.own('__isStructured', () => !!this.elements && this.kind !== 'entity')
  }

  get _isReadOnly() {
    return this.own('__isReadOnly', () => !this.key && _isReadOnly(this))
  }

  get _foreignKey4() {
    return this.own('__foreignKey4', () => foreignKey4(this))
  }
}
