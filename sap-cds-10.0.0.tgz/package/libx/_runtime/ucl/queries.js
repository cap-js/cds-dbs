const READ_QUERY = /* GraphQL */ `
  query ($key: String!, $value: String!) {
    applicationTemplates(filter: { key: $key, query: $value }) {
      data {
        id
        name
        description
        placeholders {
          name
          description
        }
        applicationInput
        labels
        webhooks {
          type
        }
      }
    }
  }
`

const CREATE_MUTATION = /* GraphQL */ `
  mutation ($input: ApplicationTemplateInput!) {
    result: createApplicationTemplate(in: $input) {
      id
      name
      labels
      applicationInput
      applicationNamespace
    }
  }
`

const UPDATE_MUTATION = /* GraphQL */ `
  mutation ($id: ID!, $input: ApplicationTemplateUpdateInput!) {
    result: updateApplicationTemplate(id: $id, in: $input) {
      id
      name
      labels
      description
      applicationInput
    }
  }
`

const DELETE_MUTATION = /* GraphQL */ `
  mutation ($id: ID!) {
    result: deleteApplicationTemplate(id: $id) {
      id
      name
      description
    }
  }
`

module.exports = {
  READ_QUERY,
  CREATE_MUTATION,
  UPDATE_MUTATION,
  DELETE_MUTATION
}
