/**
 * @param {import('../RestAdapter')} adapter
 * the adapter instance in which this middleware is used
 */
module.exports = exports = adapter => exports.update.bind(adapter)

/**
 * @type {import('express').Handler}
 * @this import('../RestAdapter')
 */
// prettier-ignore
exports.update = async function rest_update (req, res) {
  // add default values for unprovided properties
  if (req.method === 'PUT') prepare_put_requests(this.service, cds.infer.target(req._query), req._data)

  const cdsReq = this.request4({
    req, res,                         // REVISIT: should go into cds.Request
    method: req.method,               // REVISIT: should go into cds.Request
    params: req._params,              // REVISIT: eliminate req._params
    query: req._query.data(req._data) // REVISIT: eliminate req._query, req._data
  })
  let result = await this.service.send(cdsReq)
  if (Array.isArray(result) && 'affected' in result) result = cdsReq.data
  return { result }
}

const cds = require('../../_runtime/cds')
const prepare_put_requests = require('../../http/put')
