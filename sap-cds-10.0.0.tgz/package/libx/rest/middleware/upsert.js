/** 
 * @param {import('../RestAdapter')} adapter 
 * the adapter instance in which this middleware is used
 */
module.exports = exports = adapter => exports.upsert.bind(adapter)

/**
 * @type {import('express').Handler}
 * @this import('../RestAdapter')
 */
// prettier-ignore
exports.upsert = function rest_upsert (req, res) {
  return update.call(this, req, res)
    .catch(e => {
      if (!retry(e, req)) throw e

      req.method = 'POST'
      const { entity } = req._query.UPDATE
      const { keys } = getKeysAndParamsFromPath(entity, { model: this.service.model })
      const data = (req.body = JSON.parse(req._raw)) // REVISIT: eliminate req._raw
      req._data = Object.assign(data, keys)          // REVISIT: eliminate req._data
      req._query = INSERT.into(entity)               // REVISIT: eliminate req._query
      return create.call(this, req, res)             // REVISIT: Changed from calling router.handle() which is undocumented!
    })
}

const { update } = require('./update')
const { create } = require('./create')

const { getKeysAndParamsFromPath } = require('../../common/utils/path')

// REVISIT: we really need to eliminate this code || status || statusCode mess w/ cds9!
const retry = (e, req) => is404(e) || (is412(e) && req.get('if-none-match') === '*')
const is404 = e => e.code === 404 || e.status === 404 || e.statusCode === 404
const is412 = e => e.code === 412 || e.status === 412 || e.statusCode === 412
