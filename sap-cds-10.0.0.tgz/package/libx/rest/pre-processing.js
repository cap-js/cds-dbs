const getTemplate = require('../_runtime/common/utils/template')

const _picker = element => {
  const categories = []
  if (Array.isArray(element)) return
  if (element.type === 'cds.Binary' || element.type === 'cds.LargeBinary') categories.push('convert_binary')
  if (categories.length) return { categories }
}

const _processorFn = () => elementInfo => {
  const { row, key, plain } = elementInfo
  if (typeof row !== 'object') return
  if (row[key] == null) return
  for (const category of plain.categories) {
    if (category === 'convert_binary') {
      if (typeof row[key] === 'string') row[key] = Buffer.from(row[key], 'base64')
    }
  }
}

const preProcessData = (data, srv, definition) => {
  const template = getTemplate('rest-pre-processing', srv, definition, { pick: _picker })
  template.process(data, _processorFn())
}

module.exports = {
  preProcessData
}
