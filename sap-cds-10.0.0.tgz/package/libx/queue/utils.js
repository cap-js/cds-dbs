const cds = require('../../lib')

const $taskProcessorRegistered = Symbol('task processor registered')

const SCHEDULER_SERVICE = 'scheduling'
const OUTBOX_MESSAGES = 'cds.outbox.Messages'
const INTERNAL_USER = 'cds.internal.user'

// prettier-ignore
const TO_COPY = ['inbound', 'event', 'data', 'flushOpts', 'headers', 'queue', 'results', 'method', 'path', 'params', 'entity', 'service']

const registerTaskProcessor = (name, context) => {
  const registry = context[$taskProcessorRegistered] || (context[$taskProcessorRegistered] = new Set())
  if (!registry.has(name)) {
    registry.add(name)
    return true
  }
  return false
}

const createTask = (queueName, msg, context, serviceName, queueOpts) => {
  // REVISIT: use something like $cds for control data
  const _msg = {
    [INTERNAL_USER]: context.user.id,
    service: serviceName
  }

  const _newContext = {}
  for (const key in context) {
    if (!queueOpts._ignoredContext.includes(key)) _newContext[key] = context[key]
  }
  _msg.context = _newContext

  if (msg._fromSend || msg.reply) _msg._fromSend = true // send or emit?

  for (const prop of TO_COPY) if (msg[prop]) _msg[prop] = msg[prop]

  if (msg.query) {
    _msg.query = typeof msg.query.flat === 'function' ? msg.query.flat() : msg.query
    delete _msg.query._target
    delete _msg.query.__target
    delete _msg.query.target
    delete _msg.data // `req.data` should be a getter to whatever is in `req.query`
  }

  const timestamp = get100NanosecondTimestampISOString(msg.queue?.after) // needs to be different for each emit

  const taskMsg = {
    ID: cds.utils.uuid(),
    appid: cds.env.appid,
    target: queueName,
    timestamp,
    msg: JSON.stringify(_msg)
  }

  return taskMsg
}

const get100NanosecondTimestampISOString = (offset = 0) => {
  const now = new Date(Date.now() + offset)
  const nanoseconds = Number(process.hrtime.bigint() % 1_000_000_000n)
  return now.toISOString().replace('Z', `${nanoseconds}`.padStart(9, '0').substring(3, 7) + 'Z')
}

const isProviderTenant = tenant => tenant && tenant === cds.requires.multitenancy?.t0

const crypto = require('crypto')

function deterministic_uuid(input) {
  const hash = crypto.createHash('sha256').update(input).digest()
  hash[6] = (hash[6] & 0x0f) | 0x40 // version 4
  hash[8] = (hash[8] & 0x3f) | 0x80 // variant 1
  const hex = hash.toString('hex')
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20, 32)}`
}

const CRON_PATTERN = /^([0-9*][-0-9*/,]*\s+){4}[0-9*][-0-9*/,]*$/

function next_execution_time(cronExpr, fromTime = new Date()) {
  if (!CRON_PATTERN.exec(cronExpr)) throw new Error(`Invalid cron expression: '${cronExpr}'`)

  const fields = cronExpr.trim().split(/\s+/)

  const RANGES = [
    [0, 59], // minute
    [0, 23], // hour
    [1, 31], // day of month
    [1, 12], // month (1-12)
    [0, 6] // day of week (0=Sun)
  ]

  const _parseField = (field, [min, max]) => {
    const values = new Set()
    for (const part of field.split(',')) {
      const [base, stepStr] = part.split('/')
      const step = stepStr ? parseInt(stepStr) : 1
      if (base === '*') {
        for (let i = min; i <= max; i += step) values.add(i)
      } else if (base.includes('-')) {
        const [lo, hi] = base.split('-').map(Number)
        for (let i = lo; i <= hi; i += step) values.add(i)
      } else {
        const start = parseInt(base)
        if (stepStr) {
          for (let i = start; i <= max; i += step) values.add(i)
        } else {
          values.add(start)
        }
      }
    }
    return [...values].sort((a, b) => a - b)
  }

  const [minutes, hours, daysOfMonth, months, daysOfWeek] = fields.map((f, i) => _parseField(f, RANGES[i]))
  // Cron allows 7 for Sunday — normalize to 0
  const dow = new Set(daysOfWeek.map(d => (d === 7 ? 0 : d)))

  const next = new Date(fromTime)
  next.setSeconds(0, 0)
  next.setMinutes(next.getMinutes() + 1)

  const limit = new Date(fromTime)
  limit.setFullYear(limit.getFullYear() + 4)

  while (next <= limit) {
    if (!months.includes(next.getMonth() + 1)) {
      next.setMonth(next.getMonth() + 1, 1)
      next.setHours(0, 0, 0, 0)
      continue
    }
    if (!daysOfMonth.includes(next.getDate()) || !dow.has(next.getDay())) {
      next.setDate(next.getDate() + 1)
      next.setHours(0, 0, 0, 0)
      continue
    }
    if (!hours.includes(next.getHours())) {
      next.setHours(next.getHours() + 1, 0, 0, 0)
      continue
    }
    if (!minutes.includes(next.getMinutes())) {
      next.setMinutes(next.getMinutes() + 1, 0, 0)
      continue
    }
    return next
  }

  throw new Error(`No matching time found for cron expression '${cronExpr}'`)
}

// REVISIT: many of these are only used in one file... move them there?
module.exports = {
  // for new
  registerTaskProcessor,
  createTask,
  get100NanosecondTimestampISOString,
  isProviderTenant,
  OUTBOX_MESSAGES,
  INTERNAL_USER,
  SCHEDULER_SERVICE,
  // for old
  deterministic_uuid,
  CRON_PATTERN,
  next_execution_time
}
