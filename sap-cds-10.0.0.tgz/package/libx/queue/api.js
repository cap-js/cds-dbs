const cds = require('../../lib')
const LOG = cds.log('queue')

let impl
const _getImpl = () => {
  if (!impl) {
    if (cds.env.requires.scheduling) {
      LOG._debug && LOG.debug('Using scheduling-based event queue processing')
      impl = require('./processing')
    } else {
      LOG._debug && LOG.debug('Using non-scheduling-based event queue processing')
      impl = require('./index')
    }
  }
  return impl
}

module.exports = {
  get queued() {
    return _getImpl().queued
  },
  get unqueued() {
    return _getImpl().unqueued
  },
  get cdsFlush() {
    return _getImpl().cdsFlush
  }
}
