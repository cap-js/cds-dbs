//////////////////////////////////////////////////////////////////////////////
//
//    FOR COMPATIBILITY REASONS ONLY - DO NOT USE THIS MODULE ANYWHERE ELSE
//
//    For example, @cap-js/graphql used to use this, yet this is no public
//    API nor is it recommended for usage.
//
//////////////////////////////////////////////////////////////////////////////

const { prototype: rest } = require('../../rest/RestAdapter')

exports.normalizeError = err => {
  err = rest.normalized(err)
  return Object.defineProperty(err, 'toJSON', {
    value() {
      return rest.localized(this)
    }
  })
}
