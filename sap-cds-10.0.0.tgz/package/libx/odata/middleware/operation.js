const cds = require('../../../')

const { pipeline } = require('node:stream/promises')

const getODataMetadata = require('../utils/metadata')
const postProcess = require('../utils/postProcess')
const getODataResult = require('../utils/result')

const location4 = require('../../http/location')

const { getKeysAndParamsFromPath } = require('../../common/utils/path')
const {
  collectStreamMetadata,
  getReadable,
  validateMimetypeIsAcceptedOrThrow
} = require('../../common/utils/streaming')
const odataBind = require('../utils/odataBind')

const _findEdmNameFor = (definition, namespace, fullyQualified = false) => {
  let name
  if (!definition) return ''
  if (definition._isStructured) {
    const structured = [definition.name]
    while (definition.parent) {
      definition = definition.parent
      structured.unshift(definition.name)
    }
    name = structured.join('_')
  } else {
    name = definition.name
  }
  if (!name.startsWith(`${namespace}.`)) return name
  return fullyQualified ? name : name.replace(new RegExp(`^${namespace}\\.`), '')
}

const _opResultName = ({ service, returnType, operation }) => {
  const { definition: { name: namespace } } = service // prettier-ignore
  if (returnType.name) {
    const resultName = _findEdmNameFor(returnType, namespace)
    if (returnType.name.startsWith(`${namespace}.`)) {
      return `${namespace}.${resultName.replace(/\./g, '_')}`
    }
    return resultName
  }
  // bound action / function returns inline structure
  if (operation.parent) {
    const boundEntityName = _findEdmNameFor(operation.parent, namespace, true).replace(/\./g, '_')
    // REVISIT exactly this return type name is generated in edm by compiler
    return `${namespace}.return_${boundEntityName}_${_findEdmNameFor(operation, namespace)}`
  }
  // unbound action / function returns inline structure
  // REVISIT exactly this return type name is generated in edm by compiler
  return `${namespace}.return_${_findEdmNameFor(operation, namespace, true).replace(/\./g, '_')}`
}

/**
 * @param {import('../ODataAdapter')} adapter
 * the adapter instance in which this middleware is used
 */
module.exports = adapter => {
  const { service } = adapter

  return function odata_operation(req, res, next) {
    let { operation, args } = req._query.SELECT?.from.ref?.slice(-1)[0] || {}
    if (!operation) return next() //> create or read

    // NOTE: As we are outside a tx, we need to prefer cds.context.model over service.model
    const model = cds.context.model ?? service.model

    // payload & params
    const data = args || req.body

    // unbound vs. bound
    let entity, params
    if (model.definitions[operation]) {
      operation = model.definitions[operation]
    } else {
      req._query.SELECT.from.ref.pop()
      let cur = { elements: model.definitions }
      for (const each of req._query.SELECT.from.ref) {
        cur = cur.elements[each.id || each]
        if (cur._target) cur = cur._target
      }
      operation = cur.actions[operation]
      entity = cur
      const keysAndParams = getKeysAndParamsFromPath(req._query.SELECT.from, { model })
      params = keysAndParams.params

      const onCollection = !!(
        operation['@cds.odata.bindingparameter.collection'] ||
        (operation.params && [...operation.params].some(p => p?.items?.type === '$self'))
      )
      if (operation.kind === 'action' && onCollection) odataBind(data, entity)
    }

    // validate method
    if (
      (operation.kind === 'action' && req.method !== 'POST') ||
      (operation.kind === 'function' && req.method !== 'GET')
    ) {
      return next({ code: 405 })
    }

    // event
    // REVISIT: when is operation.name actually prefixed with the service name?
    const event = operation.name.replace(`${service.definition.name}.`, '')

    const query = entity ? req._query : undefined

    // cdsReq.headers should contain merged headers of envelope and subreq
    const headers = { ...cds.context.http.req.headers, ...req.headers }

    // we need a cds.Request for multiple reasons, incl. params, headers, sap-messages, read after write, ...
    const target = query && cds.infer.target(query) // FIXME: this should not happen here but only in an event handler !
    const cdsReq = adapter.request4({ query, event, data, params, headers, target, req, res })

    // prettier-ignore
    if (cdsReq.query) {
      let _q = cdsReq.query
      let warn = () => { cds.utils.deprecated({ kind: 'API', old: 'req.query for bound actions', use: 'req.subject' }); warn = () => {} }
      Object.defineProperty(cdsReq, 'query', { get() { warn(); return _q }, set(q) { warn(); _q = q } })
    }

    const _isStream = operation.returns?._type === 'cds.LargeBinary' && !!operation.returns['@Core.MediaType']

    // NOTES:
    // - only via srv.run in combination with srv.dispatch inside,
    //   we automatically either use a single auto-managed tx for the req (i.e., insert and read after write in same tx)
    //   or the auto-managed tx opened for the respective atomicity group, if exists
    // - in the then block of .run(), the transaction is committed (i.e., before sending the response) if a single auto-managed tx is used
    return service
      .run(() =>
        service.dispatch(cdsReq).then(result => {
          if (res.headersSent) return result
          if (!_isStream) return result
          adapter.sap_messages4(cdsReq, req, res)

          const stream = getReadable(result)
          if (!stream) {
            if (res.statusCode > 200) return res.end()
            return res.sendStatus(204)
          }

          const { mimetype, filename, disposition } = collectStreamMetadata(result, operation, query)
          validateMimetypeIsAcceptedOrThrow(req.headers, mimetype)
          if (!res.get('content-type')) res.set('content-type', mimetype)
          if (filename && !res.get('content-disposition'))
            res.set('content-disposition', `${disposition}; filename="${encodeURIComponent(filename)}"`)

          return pipeline(stream, res)
        })
      )
      .then(result => {
        if (res.headersSent) return

        adapter.sap_messages4(cdsReq, req, res)

        if (operation.returns?.items && result == null) result = []
        if (!operation.returns || result == null) {
          if (res.statusCode > 200) return res.end()
          return res.sendStatus(204)
        }

        if (res.statusCode === 201 && !res.hasHeader('location')) {
          const location = location4(operation.returns, service, result)
          if (location) res.set('location', location)
        }

        if (operation.returns) {
          postProcess(operation.returns, model, result)
          if (result?.$etag) res.set('ETag', result.$etag) //> must be done after post processing
        }

        // REVISIT: enterprise search result? -> simply return what was provided
        if (operation.returns.type === 'sap.esh.SearchResult') return res.send(result)

        const isCollection = !!operation.returns.items
        const _target = operation.returns.items ?? operation.returns
        const options = { result, isCollection }
        if (!_target.name) {
          // case: return inline type def
          options.edmName = _opResultName({ service, operation, returnType: _target })
        }
        const SELECT = {
          from: query ? { ref: [...query.SELECT.from.ref, { operation: operation.name }] } : {},
          one: !isCollection
        }
        const metadata = getODataMetadata({ SELECT, _target }, options)
        result = getODataResult(result, metadata, { isCollection })

        res.send(result)
      })
      .catch(err => {
        adapter.sap_messages4(cdsReq, req, res)

        next(err)
      })
  }
}
