namespace cds.core;

type State : String enum {
  CONFIG_PENDING = 'CONFIG_PENDING';
  READY = 'READY';
}

@rest
@path    : '/ucl/spii/v1'
@requires: 'any'
@impl    : '@sap/cds/srv/ucl-service.js'
service UCLService {
  @open
  @cds.persistence.skip
  entity tenantMappings {
    key tenantId       : String;
        context        : Map;
        receiverTenant : Map;
        assignedTenant : Map;
  }

  @cds.api.ignore
  action assign(tenantId: String, context: Map, receiverTenant: Map, assignedTenant: Map)   returns {
    state         : State;
    configuration : Map;
  };

  @cds.api.ignore
  action unassign(tenantId: String, context: Map, receiverTenant: Map, assignedTenant: Map) returns {
    state : String enum {
      READY = 'READY';
    }
  };

  @cds.api.ignore
  action add(tenantId: String, context: Map, receiverTenant: Map, assignedTenant: Map)      returns {
    state         : State;
    configuration : Map
  }

  @cds.api.ignore
  action remove(tenantId: String, context: Map, receiverTenant: Map, assignedTenant: Map)   returns {
    state         : State;
    configuration : Map
  }

  @cds.api.ignore
  action modify(tenantId: String, context: Map, receiverTenant: Map, assignedTenant: Map)   returns {
    state         : State;
    configuration : Map
  }

  @cds.api.ignore
  action rotate(tenantId: String, context: Map, receiverTenant: Map, assignedTenant: Map)   returns {
    state         : State;
    configuration : Map
  }
}
