module.exports = require('@cap-js/db-service').DatabaseService
