module.exports = require('../libx/_runtime/messaging/service')
