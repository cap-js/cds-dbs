module.exports = require('../libx/_runtime/remote/Service')
